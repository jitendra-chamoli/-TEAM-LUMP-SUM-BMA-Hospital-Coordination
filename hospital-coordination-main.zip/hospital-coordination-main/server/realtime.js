// Socket.IO wiring. Every connection must present a valid JWT; it then joins
// one room for its hospital and one for the user, so events only reach the
// hospital they belong to (and a deactivated user can be disconnected).

const { Server } = require('socket.io');
const { authenticateToken } = require('./middleware/authMiddleware');

let io = null;

const hospitalRoom = (hospitalId) => `hospital:${hospitalId}`;
const userRoom = (userId) => `user:${userId}`;

function initRealtime(httpServer, clientUrl) {
    io = new Server(httpServer, {
        cors: { origin: clientUrl, methods: ['GET', 'POST', 'PATCH', 'DELETE'] }
    });

    io.use(async (socket, next) => {
        try {
            socket.user = await authenticateToken(socket.handshake.auth?.token);
            next();
        } catch (err) {
            next(new Error(err.message || 'Unauthorized'));
        }
    });

    io.on('connection', (socket) => {
        socket.join(hospitalRoom(socket.user.hospital_id));
        socket.join(userRoom(socket.user.id));
    });

    return io;
}

// Emit to everyone signed in at one or more hospitals (duplicates are ignored).
function emitToHospitals(hospitalIds, event, payload) {
    if (!io) return;
    const rooms = [...new Set([].concat(hospitalIds).filter(Boolean))].map(hospitalRoom);
    if (rooms.length) io.to(rooms).emit(event, payload);
}

// Emit to one signed-in user on all their devices (e.g. the driver of an ambulance).
function emitToUser(userId, event, payload) {
    if (io && userId) io.to(userRoom(userId)).emit(event, payload);
}

function disconnectUser(userId) {
    if (io) io.in(userRoom(userId)).disconnectSockets(true);
}

module.exports = { initRealtime, emitToHospitals, emitToUser, disconnectUser };
