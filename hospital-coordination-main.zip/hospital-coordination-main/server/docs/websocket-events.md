# WebSocket events

Clients connect with `io(API_URL, { auth: { token } })`. The server rejects connections without a valid token for an active account, then puts each socket in a room for its hospital. Every event below is sent only to the hospital(s) it concerns.

| Event                     | Sent to | Payload |
| ------------------------- | ------- | ------- |
| staff_changed             | hospital | Full staff row (`id, name, email, department, is_active, must_change_password, …`), sent when staff are added, edited, deactivated or have their password reset |
| doctor_changed            | hospital | Full doctor row (`id, doctor_name, department, status, specialization, phone, next_shift_start, next_shift_end, login_email, …`) |
| doctor_removed            | hospital | `{ id }` |
| resource_updated          | hospital | `{ id, newValue, capacity }` |
| resource_created          | hospital | `{ id }`, sent when a department starts tracking a resource; clients refetch |
| critical_resource_alert   | hospital | `{ hospital_id, resource_name, department }`, fired when a resource hits 0 |
| activity_logged           | hospital | `{ id, action, entity_type, entity_id, summary, user_id, user_name, created_at }` (`user_id` is null for the shift schedule) |
| incident_request          | asked hospital | Request payload (`request_id, incident_id, expires_at, timeout_seconds, complaint_label, severity, needs_icu, patient_*, notes, distance_km, requested_by_*`) |
| incident_request_closed   | asked hospital | `{ incident_id, request_id, outcome: accepted \| diverted \| expired \| cancelled, by? }`: close the alert |
| incident_updated          | requesting + current/receiving hospital, and the ambulance's driver | Full incident summary (status, timestamps, hospital, ambulance, doctor, `pending_request`) |
| ambulance_location_update | requesting + current/receiving hospital, and the ambulance's driver | `{ incident_id, lat, lng, leg: to_patient \| to_hospital, eta_seconds }`, every second |
| fleet_updated             | hospital | `{}`: an ambulance or driver changed (shift, assignment, retire); clients refetch `/api/fleet` |
| fleet_location            | hospital | `{ ambulance_id, lat, lng, accuracy, at }`: a driver's phone reported a position |

The public (citizen) app does not use sockets at all: it polls `GET /api/public/requests/:id`
every 5 seconds. That keeps citizen tokens out of the socket layer and copes better with a
patchy mobile connection.

When an account is deactivated, has its password reset, or (for a doctor) is removed from the roster, the server disconnects that user's sockets.
