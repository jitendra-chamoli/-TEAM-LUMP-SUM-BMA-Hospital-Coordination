// Validates req.body against a Zod schema; replaces it with the parsed
// (type-coerced, trimmed) value so controllers can trust their inputs.
const validate = (schema) => (req, res, next) => {
    const result = schema.safeParse(req.body);

    if (!result.success) {
        return res.status(400).json({
            error: "Validation failed",
            details: result.error.issues.map(i => ({ field: i.path.join('.'), message: i.message }))
        });
    }

    req.body = result.data;
    next();
};

module.exports = validate;
