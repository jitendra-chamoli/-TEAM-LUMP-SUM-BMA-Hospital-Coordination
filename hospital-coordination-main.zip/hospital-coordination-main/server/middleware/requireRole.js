// Use after verifyToken: rejects users whose JWT role isn't in the allowed list.
const requireRole = (...roles) => (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
        return res.status(403).json({ message: "You don't have permission to do this." });
    }
    next();
};

module.exports = requireRole;
