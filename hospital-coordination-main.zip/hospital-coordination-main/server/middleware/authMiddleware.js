const jwt = require('jsonwebtoken');
const db = require('../config/db');

class AuthError extends Error {
    constructor(status, message, code) {
        super(message);
        this.status = status;
        this.code = code;
    }
}

// The JWT only proves who the user is. Role, department and active status are
// read fresh from the database on every request, so deactivating an account or
// moving someone to another department takes effect immediately.
const authenticateToken = async (token) => {
    if (!token) throw new AuthError(403, 'No token provided');

    let decoded;
    try {
        decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch {
        throw new AuthError(401, 'Unauthorized');
    }

    const [[user]] = await db.query(`
        SELECT u.id, u.name, u.email, u.phone, u.role, u.hospital_id, u.doctor_id, u.ambulance_id,
               u.is_active, u.must_change_password,
               COALESCE(doc_dept.name, d.name) AS department,
               h.name AS hospital_name
        FROM users u
        JOIN hospitals h            ON h.id = u.hospital_id
        LEFT JOIN departments d     ON d.id = u.department_id
        LEFT JOIN doctors doc       ON doc.id = u.doctor_id
        LEFT JOIN departments doc_dept ON doc_dept.id = doc.department_id
        WHERE u.id = ?`, [decoded.id]);

    if (!user) throw new AuthError(401, 'Account not found', 'ACCOUNT_REMOVED');
    if (!user.is_active) throw new AuthError(401, 'Your account has been deactivated', 'ACCOUNT_DEACTIVATED');

    return user;
};

const buildMiddleware = ({ allowPendingPasswordChange }) => async (req, res, next) => {
    const token = req.headers['authorization']?.split(' ')[1]; // Handle "Bearer <token>"

    try {
        req.user = await authenticateToken(token);
    } catch (err) {
        if (!(err instanceof AuthError)) {
            console.error('Auth lookup failed:', err.message);
            return res.status(500).json({ message: 'Could not verify your session' });
        }
        return res.status(err.status).json({ message: err.message, code: err.code });
    }

    // Accounts created with a temporary password can only change it until they do.
    if (req.user.must_change_password && !allowPendingPasswordChange) {
        return res.status(403).json({ message: 'Set a new password to continue', code: 'PASSWORD_CHANGE_REQUIRED' });
    }

    next();
};

const verifyToken = buildMiddleware({ allowPendingPasswordChange: false });
const verifyTokenAllowPasswordChange = buildMiddleware({ allowPendingPasswordChange: true });

module.exports = { verifyToken, verifyTokenAllowPasswordChange, authenticateToken };
