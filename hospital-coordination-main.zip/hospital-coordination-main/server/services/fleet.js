// Which ambulances can be sent on a job.
//  - Hospital ambulances: a driver is on shift and their phone sent a GPS fix recently.
//  - Demo ambulances (imported sample fleet): always, unless USE_DEMO_AMBULANCES=false.
// hospital-orchestrator/server.js applies the same rule when suggesting an ambulance.

const GPS_STALE_MINUTES = Number(process.env.GPS_STALE_MINUTES) || 10;
const USE_DEMO_AMBULANCES = process.env.USE_DEMO_AMBULANCES !== 'false';

function dispatchableAmbulances(alias = 'a') {
    const since = new Date(Date.now() - GPS_STALE_MINUTES * 60 * 1000);
    const demo = USE_DEMO_AMBULANCES ? `${alias}.location_source = 'demo' OR ` : '';
    return {
        sql: `${alias}.status = 'available' AND ${alias}.is_active AND ${alias}.latitude IS NOT NULL
              AND (${demo}(${alias}.location_source = 'gps' AND ${alias}.current_driver_id IS NOT NULL AND ${alias}.location_updated_at >= ?))`,
        params: [since]
    };
}

module.exports = { dispatchableAmbulances, GPS_STALE_MINUTES };
