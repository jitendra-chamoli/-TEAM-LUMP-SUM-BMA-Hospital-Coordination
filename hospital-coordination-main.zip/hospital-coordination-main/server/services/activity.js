// Records "who changed what" for the Activity tab. Logging must never break the
// action being logged, so failures are only printed.

const db = require('../config/db');
const { emitToHospitals } = require('../realtime');

async function logActivity({ hospitalId, user = null, action, entityType, entityId = null, summary }) {
    try {
        const [result] = await db.query(
            `INSERT INTO activity_log (hospital_id, user_id, action, entity_type, entity_id, summary)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [hospitalId, user ? user.id : null, action, entityType, entityId, summary.slice(0, 255)]
        );

        emitToHospitals(hospitalId, 'activity_logged', {
            id: result.insertId,
            action,
            entity_type: entityType,
            entity_id: entityId,
            summary,
            user_id: user ? user.id : null,
            user_name: user ? user.name : 'System',
            created_at: new Date().toISOString()
        });
    } catch (err) {
        console.error('Activity log failed:', err.message);
    }
}

module.exports = { logActivity };
