// Asks the orchestrator to rank hospitals for a public request.
//
// Hospital staff call the orchestrator straight from the browser with their own
// token. A public request has no hospital user, so the server calls it instead,
// using a short-lived service token signed with the shared JWT_SECRET.

const axios = require('axios');
const jwt = require('jsonwebtoken');

const ORCHESTRATOR_URL = process.env.ORCHESTRATOR_URL || 'http://127.0.0.1:5001';

const serviceToken = () => jwt.sign({ id: 0, role: 'service' }, process.env.JWT_SECRET, { expiresIn: '2m' });

/**
 * Returns { options, ambulance, radius_km }. Throws a plain Error on failure;
 * the caller decides what the citizen sees.
 */
async function rankHospitals({ lat, lng, severity, needsIcu, complaint, specialistDepartments, preferSchemes, preferTypes }) {
    const res = await axios.post(`${ORCHESTRATOR_URL}/api/recommend`, {
        patient_lat: lat,
        patient_lng: lng,
        severity,
        needs_icu: needsIcu,
        complaint,
        specialist_departments: specialistDepartments,
        prefer_schemes: preferSchemes,
        prefer_types: preferTypes
    }, { headers: { Authorization: `Bearer ${serviceToken()}` }, timeout: 12000 });
    return res.data;
}

module.exports = { rankHospitals, ORCHESTRATOR_URL };
