// Dispatch workflow.
//
//   requested ──accept──▶ accepted ──(ambulance reaches patient)──▶ picked_up ──▶ arrived ──▶ handed_over ──▶ closed
//       │  └─every hospital diverts / nobody answers─▶ 'unplaced'
//       └──────────────────────────── cancel (any time before hand-over) ──────────────────────────▶ cancelled
//
// Every candidate hospital is asked at the same moment, not one after another, and
// the first to accept gets the patient. Asking in turn meant a patient could wait
// five timeouts before the fifth hospital had even seen the request.
//
// Because answers can now arrive together, "first" is decided over a short claim
// window rather than by whose click landed first: see winRace().
//
// Two searches start the moment a request is made, and neither waits for the other:
//   - hospitals: every candidate is asked at once (askAll / accept / winRace)
//   - a driver : the nearest few drivers on shift are offered the job at once and
//                the first to accept gets it (offerAmbulance / acceptOffer). If nobody
//                accepts in time, the next few nearest are asked.
// The ambulance drives to the patient as soon as a driver accepts; the hospital
// decision only decides where it goes after that.
//
// Nothing here moves an ambulance. Something reports where it is -- a driver's phone
// (POST /api/driver/location), a vehicle tracker or the demo simulator
// (POST /api/telemetry/positions) -- and reportPosition() works out what that means
// for the job: a new ETA, or arrival at the patient or the hospital. Everything it
// needs is read from the database, so there is no in-memory trip state to lose on
// a restart. Drivers can also tap "Picked up" / "Arrived" by hand.

const db = require('../config/db');
const { emitToHospitals, emitToUser } = require('../realtime');
const { logActivity } = require('./activity');
const { complaintByCode, EMERGENCY_DEPARTMENTS, DIVERT_REASONS } = require('../config/complaints');
const { dispatchableAmbulances } = require('./fleet');
const { resolvePayerRoute, schemeForRoute, isMlc } = require('../config/payers');
const { rankHospitals } = require('./recommend');
const routing = require('./routing');

// One shared deadline for every hospital asked. Shorter than the old per-hospital
// timeout because it is no longer paid five times over.
const REQUEST_TIMEOUT_SECONDS = Number(process.env.DISPATCH_DEADLINE_SECONDS)
    || Number(process.env.DISPATCH_REQUEST_TIMEOUT_SECONDS) || 45;
// How many hospitals are asked at once.
const DISPATCH_FANOUT = Number(process.env.DISPATCH_FANOUT) || 5;
// How long a lower-ranked hospital's acceptance waits to see whether a better-ranked
// one is answering too. Long enough to cover the gap between two near-simultaneous
// clicks, short enough that nobody notices the pause.
const CLAIM_WINDOW_MS = Number(process.env.DISPATCH_CLAIM_WINDOW_MS) || 2000;

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Drivers offered a job at once, how long they have to accept, and how many rounds
// of "next nearest" before the caller is told no ambulance could be found.
const OFFER_FANOUT = Number(process.env.AMBULANCE_OFFER_FANOUT) || 3;
const OFFER_SECONDS = Number(process.env.AMBULANCE_OFFER_SECONDS) || 20;
const OFFER_ROUNDS = Number(process.env.AMBULANCE_OFFER_ROUNDS) || 3;
// An offer can be accepted while the patient still needs picking up.
const OFFERABLE_STATUSES = ['requested', 'accepted', 'unplaced'];

const ACTIVE_STATUSES = ['requested', 'accepted', 'picked_up', 'arrived'];

// How close counts as "reached". ETAs come from road routes: see services/routing.js.
const ARRIVE_PATIENT_KM = 0.15;
const ARRIVE_HOSPITAL_KM = 0.25;

class DispatchError extends Error {
    constructor(status, message) {
        super(message);
        this.status = status;
    }
}

const haversineKm = (lat1, lng1, lat2, lng2) => {
    const R = 6371, rad = (x) => (x * Math.PI) / 180;
    const dLat = rad(lat2 - lat1), dLng = rad(lng2 - lng1);
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
};

// mysql2 renders an empty array as `IN ()`, which is invalid SQL.
const inList = (values) => (values.length ? values : ['']);

// ---------------- Reading incidents ---------------- //

const INCIDENT_SELECT = `
    SELECT i.*,
           h.name AS hospital_name, h.latitude AS hospital_lat, h.longitude AS hospital_lng, h.phone AS hospital_phone,
           rh.name AS requested_by_hospital_name,
           ru.name AS requested_by_name,
           a.driver_name AS ambulance_name, a.contact AS ambulance_contact, a.latitude AS ambulance_lat, a.longitude AS ambulance_lng,
           a.vehicle_number AS ambulance_vehicle, a.type AS ambulance_type, a.location_source AS ambulance_source,
           a.current_driver_id AS ambulance_driver_id, a.location_updated_at AS ambulance_location_at,
           doc.name AS receiving_doctor_name, doc.phone AS receiving_doctor_phone,
           pr.id AS pending_request_id, pr.expires_at AS pending_expires_at,
           h.type AS hospital_type, h.address AS hospital_address
    FROM incidents i
    JOIN hospitals h            ON h.id = i.hospital_id
    LEFT JOIN hospitals rh      ON rh.id = i.requested_by_hospital_id
    LEFT JOIN users ru          ON ru.id = i.requested_by_user_id
    LEFT JOIN ambulances a      ON a.id = i.ambulance_id
    LEFT JOIN doctors doc       ON doc.id = i.receiving_doctor_id
    LEFT JOIN incident_requests pr ON pr.incident_id = i.id AND pr.status = 'pending'`;

const num = (v) => (v === null || v === undefined ? null : Number(v));

const toSummary = (row) => ({
    id: row.id,
    status: row.status,
    severity: row.severity,
    needs_icu: Boolean(row.needs_icu),
    complaint: row.complaint,
    complaint_label: complaintByCode(row.complaint).label,
    patient_name: row.patient_name,
    patient_age: row.patient_age,
    patient_sex: row.patient_sex,
    caller_phone: row.caller_phone,
    notes: row.notes,
    pickup_address: row.pickup_address,
    city: row.city,
    patient_lat: num(row.patient_lat),
    patient_lng: num(row.patient_lng),
    distance_km: num(row.distance_km),
    hospital_id: row.hospital_id,
    hospital_name: row.hospital_name,
    hospital_phone: row.hospital_phone,
    hospital_address: row.hospital_address,
    hospital_type: row.hospital_type,
    source: row.source,
    requester_relationship: row.requester_relationship,
    patient_identified: Boolean(row.patient_identified),
    is_mlc: Boolean(row.is_mlc),
    motor_vehicle_involved: row.motor_vehicle_involved === null ? null : Boolean(row.motor_vehicle_involved),
    vehicle_numbers: row.vehicle_numbers,
    payer_route: row.payer_route,
    payer_note: row.payer_note,
    police_informed_at: row.police_informed_at,
    public_user_id: row.public_user_id,
    hospital_lat: num(row.hospital_lat),
    hospital_lng: num(row.hospital_lng),
    requested_by_hospital_id: row.requested_by_hospital_id,
    requested_by_hospital_name: row.requested_by_hospital_name,
    requested_by_name: row.requested_by_name,
    ambulance_id: row.ambulance_id,
    ambulance_search: row.ambulance_search,
    ambulance_name: row.ambulance_name,
    ambulance_contact: row.ambulance_contact,
    ambulance_lat: num(row.ambulance_lat),
    ambulance_lng: num(row.ambulance_lng),
    ambulance_vehicle: row.ambulance_vehicle,
    ambulance_type: row.ambulance_type,
    ambulance_source: row.ambulance_source,
    ambulance_driver_id: row.ambulance_driver_id,
    ambulance_location_at: row.ambulance_location_at,
    receiving_doctor_name: row.receiving_doctor_name,
    receiving_doctor_phone: row.receiving_doctor_phone,
    created_at: row.dispatched_at,
    accepted_at: row.accepted_at,
    picked_up_at: row.picked_up_at,
    arrived_at: row.arrived_at,
    handed_over_at: row.handed_over_at,
    closed_at: row.closed_at,
    cancelled_at: row.cancelled_at,
    cancel_reason: row.cancel_reason,
    pending_request: row.pending_request_id ? { id: row.pending_request_id, expires_at: row.pending_expires_at } : null
});

async function getSummary(incidentId) {
    const [[row]] = await db.query(`${INCIDENT_SELECT} WHERE i.id = ?`, [incidentId]);
    return row ? toSummary(row) : null;
}

async function listForHospital(hospitalId) {
    const [rows] = await db.query(
        `${INCIDENT_SELECT} WHERE i.hospital_id = ? OR i.requested_by_hospital_id = ? ORDER BY i.dispatched_at DESC LIMIT 100`,
        [hospitalId, hospitalId]
    );
    return rows.map(toSummary);
}

// Full detail for the incident sheet: summary + every hospital asked + bed holds.
async function getDetail(incidentId) {
    const summary = await getSummary(incidentId);
    if (!summary) return null;
    const [attempts] = await db.query(`
        SELECT r.id, r.hospital_id, h.name AS hospital_name, r.rank_order, r.status, r.reason,
               r.sent_at, r.responded_at, u.name AS responded_by_name
        FROM incident_requests r
        JOIN hospitals h ON h.id = r.hospital_id
        LEFT JOIN users u ON u.id = r.responded_by
        WHERE r.incident_id = ? ORDER BY r.rank_order`, [incidentId]);
    const [holds] = await db.query(`
        SELECT b.id, b.status, rt.name AS resource_name, d.name AS department
        FROM bed_holds b
        JOIN hospital_resources r ON r.id = b.resource_id
        JOIN resource_types rt ON rt.id = r.resource_type_id
        JOIN departments d ON d.id = r.department_id
        WHERE b.incident_id = ?`, [incidentId]);
    return { ...summary, attempts, bed_holds: holds };
}

// Who may act on an incident: the hospital receiving the patient and the one that
// asked. Deliberately narrower than canRead -- being asked is not being in charge.
const involves = (summary, hospitalId) =>
    summary.hospital_id === hospitalId || summary.requested_by_hospital_id === hospitalId;

// Who may open the incident. Since every candidate is asked at once, four of the five
// are not the destination and would otherwise get "Incident not found" for the very
// patient they are being asked to take.
async function canRead(incidentId, summary, hospitalId) {
    if (involves(summary, hospitalId)) return true;
    const [[asked]] = await db.query(
        'SELECT 1 AS yes FROM incident_requests WHERE incident_id = ? AND hospital_id = ? LIMIT 1',
        [incidentId, hospitalId]
    );
    return Boolean(asked);
}

const roomsFor = (summary) => [summary.requested_by_hospital_id, summary.hospital_id];

// Hospitals involved, plus the driver of the assigned ambulance.
function emitIncident(summary) {
    emitToHospitals(roomsFor(summary), 'incident_updated', summary);
    emitToUser(summary.ambulance_driver_id, 'incident_updated', summary);
}

async function broadcast(incidentId) {
    const summary = await getSummary(incidentId);
    if (summary) emitIncident(summary);
    return summary;
}

// What the receiving hospital sees in its "incoming request" alert.
// state: 'pending' (live, counting down) or 'missed' (timed out, but no hospital has accepted yet).
const requestPayload = (summary, request, state = 'pending') => ({
    state,
    request_id: request.id,
    incident_id: summary.id,
    expires_at: request.expires_at,
    timeout_seconds: REQUEST_TIMEOUT_SECONDS,
    // Other hospitals are looking at this same patient right now. Saying so, and
    // saying where this one placed, is the difference between "answer when you get
    // to it" and "answer now or someone else will".
    rank_order: request.rank_order,
    asked_count: request.asked_count,
    severity: summary.severity,
    needs_icu: summary.needs_icu,
    complaint: summary.complaint,
    complaint_label: summary.complaint_label,
    patient_name: summary.patient_name,
    patient_age: summary.patient_age,
    patient_sex: summary.patient_sex,
    notes: summary.notes,
    pickup_address: summary.pickup_address,
    distance_km: summary.distance_km,
    requested_by_hospital_name: summary.requested_by_hospital_name,
    requested_by_name: summary.requested_by_name,
    source: summary.source,
    requester_relationship: summary.requester_relationship,
    patient_identified: summary.patient_identified,
    is_mlc: summary.is_mlc,
    payer_route: summary.payer_route
});

async function pendingRequestsForHospital(hospitalId) {
    const [rows] = await db.query(`
        SELECT r.id, r.incident_id, r.expires_at, r.status, r.rank_order,
               (SELECT COUNT(*) FROM incident_requests c WHERE c.incident_id = r.incident_id) AS asked_count
        FROM incident_requests r
        JOIN incidents i ON i.id = r.incident_id
        WHERE r.hospital_id = ?
          AND (r.status = 'pending' OR (r.status = 'expired' AND i.status IN ('requested', 'unplaced')))
        ORDER BY r.status = 'pending' DESC, r.sent_at`, [hospitalId]);
    const out = [];
    for (const r of rows) {
        const summary = await getSummary(r.incident_id);
        if (summary) out.push(requestPayload(summary, r, r.status === 'pending' ? 'pending' : 'missed'));
    }
    return out;
}

// Hospitals that let the request time out still see it as "missed" until someone accepts;
// tell them when that's no longer possible.
async function closeMissedRequests(incidentId, outcome, exceptHospitalId = null) {
    const [missed] = await db.query(
        "SELECT id, hospital_id FROM incident_requests WHERE incident_id = ? AND status = 'expired'",
        [incidentId]
    );
    for (const m of missed) {
        if (m.hospital_id !== exceptHospitalId) {
            emitToHospitals(m.hospital_id, 'incident_request_closed', { incident_id: incidentId, request_id: m.id, outcome });
        }
    }
}

// ---------------- Creating a request ---------------- //

// Where the ambulance is currently driving. Until someone accepts, this is the
// best-ranked candidate rather than a decision: the ambulance cannot wait for one.
async function setDestination(incidentId, hospitalId) {
    const [[hospital]] = await db.query('SELECT latitude, longitude FROM hospitals WHERE id = ?', [hospitalId]);
    const [[inc]] = await db.query('SELECT patient_lat, patient_lng FROM incidents WHERE id = ?', [incidentId]);
    const distance = haversineKm(Number(inc.patient_lat), Number(inc.patient_lng), Number(hospital.latitude), Number(hospital.longitude));
    await db.query('UPDATE incidents SET hospital_id = ?, distance_km = ? WHERE id = ?', [hospitalId, distance.toFixed(2), incidentId]);
}

/**
 * body: { patient_lat, patient_lng, pickup_address, city, complaint, severity, needs_icu,
 *         patient_name, patient_age, patient_sex, caller_phone, notes,
 *         hospital_ids: [ranked candidates, chosen first], ambulance_id }
 */
async function createIncident(user, body) {
    const hospitalIds = [...new Set(body.hospital_ids)].slice(0, DISPATCH_FANOUT);
    const [found] = await db.query('SELECT id FROM hospitals WHERE id IN (?)', [hospitalIds]);
    if (found.length !== hospitalIds.length) throw new DispatchError(400, 'One of the chosen hospitals no longer exists.');

    const [result] = await db.query(`
        INSERT INTO incidents
            (hospital_id, ambulance_id, requested_by_user_id, requested_by_hospital_id, status,
             city, patient_name, patient_age, patient_sex, caller_phone, complaint, notes, pickup_address,
             patient_lat, patient_lng, severity, needs_icu, dispatched_at)
        VALUES (?, ?, ?, ?, 'requested', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [hospitalIds[0], null, user.id, user.hospital_id,
         body.city || null, body.patient_name || null, body.patient_age ?? null, body.patient_sex || null,
         body.caller_phone || null, body.complaint, body.notes || null, body.pickup_address || null,
         body.patient_lat, body.patient_lng, body.severity, Boolean(body.needs_icu), new Date()]);
    const incidentId = result.insertId;

    for (const [i, hospitalId] of hospitalIds.entries()) {
        await db.query('INSERT INTO incident_requests (incident_id, hospital_id, rank_order) VALUES (?, ?, ?)', [incidentId, hospitalId, i + 1]);
    }

    await askAll(incidentId);
    const drivers = await offerAmbulance(incidentId);

    const summary = await getSummary(incidentId);
    await logActivity({
        hospitalId: user.hospital_id, user, action: 'incident.requested', entityType: 'incident', entityId: incidentId,
        summary: `Dispatch #${incidentId} (${summary.complaint_label}, ${summary.severity}): asked ${hospitalIds.length} `
            + `hospital${hospitalIds.length === 1 ? '' : 's'} at once, best match ${summary.hospital_name}`
            + `${drivers ? `, offered to the ${drivers} nearest ambulance${drivers === 1 ? '' : 's'}` : ', no ambulance free'}`
    });
    return getDetail(incidentId);
}

/**
 * A member of the public books an ambulance. There is no hospital user, so the
 * server ranks hospitals itself and asks the best three in order.
 *
 * body: { patient_lat, patient_lng, pickup_address, complaint, severity, needs_icu,
 *         relationship: self|family|bystander, patient_identified, patient_name,
 *         patient_age, patient_sex, notes, motor_vehicle_involved, vehicle_numbers,
 *         payer, payer_note }
 */
async function createPublicIncident(publicUser, body) {
    const complaint = body.complaint;
    const motorVehicle = Boolean(body.motor_vehicle_involved);
    const bystander = body.relationship === 'bystander';
    // A bystander can't commit a stranger to a private bill, so their request is
    // always routed as an unknown payer regardless of what was selected.
    const payer = bystander ? 'unknown' : body.payer;
    const payerRoute = resolvePayerRoute({ complaint, motorVehicle, payer });
    const identified = bystander ? Boolean(body.patient_identified) : true;

    const specialists = complaintByCode(complaint).departments;
    // Cost never steers a critical case: it goes to the nearest capable hospital.
    const costMatters = body.severity !== 'critical';
    const scheme = schemeForRoute(payerRoute);

    let ranked;
    try {
        ranked = await rankHospitals({
            lat: body.patient_lat, lng: body.patient_lng,
            severity: body.severity, needsIcu: Boolean(body.needs_icu),
            complaint, specialistDepartments: specialists,
            preferSchemes: costMatters && scheme ? [scheme] : [],
            // An unknown payer leans towards hospitals that are funded to absorb the cost.
            preferTypes: costMatters && payerRoute === 'unknown' ? ['government', 'trust'] : []
        });
    } catch (err) {
        const detail = err.response?.data?.error;
        throw new DispatchError(err.response?.status === 404 ? 404 : 503,
            detail || 'No hospitals could be reached right now. Please call 108.');
    }

    const hospitalIds = (ranked.options || []).map(o => o.id).slice(0, DISPATCH_FANOUT);
    if (hospitalIds.length === 0) throw new DispatchError(404, 'No hospital with free beds was found nearby. Please call 108.');

    const [result] = await db.query(`
        INSERT INTO incidents
            (hospital_id, ambulance_id, status, source, public_user_id, requester_relationship,
             patient_identified, is_mlc, motor_vehicle_involved, vehicle_numbers, payer_route, payer_note,
             city, patient_name, patient_age, patient_sex, caller_phone, complaint, notes, pickup_address,
             patient_lat, patient_lng, severity, needs_icu, dispatched_at)
        VALUES (?, ?, 'requested', 'public', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [hospitalIds[0], null, publicUser.id, body.relationship,
         identified, isMlc(complaint, motorVehicle), body.motor_vehicle_involved ?? null,
         body.vehicle_numbers || null, payerRoute, body.payer_note || null,
         body.city || null, body.patient_name || null, body.patient_age ?? null, body.patient_sex || null,
         body.caller_phone || null, complaint, body.notes || null, body.pickup_address || null,
         body.patient_lat, body.patient_lng, body.severity, Boolean(body.needs_icu), new Date()]);
    const incidentId = result.insertId;

    for (const [i, hospitalId] of hospitalIds.entries()) {
        await db.query('INSERT INTO incident_requests (incident_id, hospital_id, rank_order) VALUES (?, ?, ?)', [incidentId, hospitalId, i + 1]);
    }

    await askAll(incidentId);
    await offerAmbulance(incidentId);
    return publicView(await getSummary(incidentId));
}

function publicEta(summary) {
    const cached = routing.cachedRoute(summary.id);
    if (!cached || summary.ambulance_lat === null) return null;
    const leg = legOf(summary);
    if (leg === 'waiting' || !cached.key.startsWith(`${leg}:`)) return null;
    const p = routing.progressFor(summary.id, cached.route, [Number(summary.ambulance_lat), Number(summary.ambulance_lng)], false);
    return { leg, seconds: p.eta_seconds, remaining_km: Number(p.remaining_km.toFixed(2)),
        source: cached.route.source, traffic: cached.route.traffic, route_version: cached.version };
}

// What the citizen who booked is allowed to see. Deliberately narrow: no bed holds,
// no other hospitals' divert reasons, nothing about the hospital's internal state.
function publicView(summary) {
    if (!summary) return null;
    return {
        id: summary.id,
        status: summary.status,
        severity: summary.severity,
        complaint: summary.complaint,
        complaint_label: summary.complaint_label,
        needs_icu: summary.needs_icu,
        patient_name: summary.patient_name,
        pickup_address: summary.pickup_address,
        caller_phone: summary.caller_phone,
        notes: summary.notes,
        patient_lat: summary.patient_lat,
        patient_lng: summary.patient_lng,
        relationship: summary.requester_relationship,
        patient_identified: summary.patient_identified,
        hospital_name: summary.accepted_at ? summary.hospital_name : null,
        hospital_phone: summary.accepted_at ? summary.hospital_phone : null,
        hospital_address: summary.accepted_at ? summary.hospital_address : null,
        hospital_lat: summary.accepted_at ? summary.hospital_lat : null,
        hospital_lng: summary.accepted_at ? summary.hospital_lng : null,
        receiving_doctor_name: summary.receiving_doctor_name,
        ambulance_name: summary.ambulance_name,
        ambulance_contact: summary.ambulance_contact,
        ambulance_vehicle: summary.ambulance_vehicle,
        ambulance_lat: summary.ambulance_lat,
        ambulance_lng: summary.ambulance_lng,
        ambulance_search: summary.ambulance_search,
        eta: publicEta(summary),
        distance_km: summary.distance_km,
        created_at: summary.created_at,
        accepted_at: summary.accepted_at,
        picked_up_at: summary.picked_up_at,
        arrived_at: summary.arrived_at,
        handed_over_at: summary.handed_over_at,
        cancelled_at: summary.cancelled_at,
        cancel_reason: summary.cancel_reason
    };
}

// The citizen's own active request, if any.
async function activePublicIncident(publicUserId) {
    const [[row]] = await db.query(
        `SELECT id FROM incidents WHERE public_user_id = ?
         AND status IN ('requested', 'accepted', 'picked_up', 'arrived', 'unplaced')
         ORDER BY id DESC LIMIT 1`, [publicUserId]);
    return row ? publicView(await getSummary(row.id)) : null;
}

async function publicIncidentFor(publicUserId, incidentId) {
    const summary = await getSummary(incidentId);
    if (!summary || summary.public_user_id !== publicUserId) throw new DispatchError(404, 'Request not found');
    return publicView(summary);
}

/**
 * The caller fills in details after dispatch. Booking deliberately requires nothing
 * but a location, so most of what the hospital needs arrives through here while the
 * ambulance is already on its way.
 *
 * Changing the complaint or severity does not re-rank hospitals: one is already
 * driving and one has been asked. The hospital sees the update immediately and can
 * divert if it is no longer the right place.
 */
async function updatePublicIncident(publicUser, incidentId, body) {
    const summary = await getSummary(incidentId);
    if (!summary || summary.public_user_id !== publicUser.id) throw new DispatchError(404, 'Request not found');
    if (!ACTIVE_STATUSES.includes(summary.status) && summary.status !== 'unplaced') {
        throw new DispatchError(409, 'This request has finished and can no longer be changed.');
    }

    const columns = {
        caller_phone: 'caller_phone', complaint: 'complaint', severity: 'severity',
        needs_icu: 'needs_icu', relationship: 'requester_relationship',
        patient_identified: 'patient_identified', patient_name: 'patient_name',
        patient_age: 'patient_age', patient_sex: 'patient_sex', notes: 'notes',
        motor_vehicle_involved: 'motor_vehicle_involved', vehicle_numbers: 'vehicle_numbers'
    };
    const sets = [], params = [];
    for (const [key, column] of Object.entries(columns)) {
        if (body[key] === undefined) continue;
        sets.push(`${column} = ?`);
        params.push(body[key] === '' ? null : body[key]);
    }

    // The cause may have changed, so whether this is a police case can change too.
    const complaint = body.complaint ?? summary.complaint;
    const motorVehicle = body.motor_vehicle_involved ?? summary.motor_vehicle_involved;
    if (body.complaint !== undefined || body.motor_vehicle_involved !== undefined) {
        sets.push('is_mlc = ?', 'payer_route = ?');
        params.push(isMlc(complaint, motorVehicle));
        params.push(resolvePayerRoute({ complaint, motorVehicle, payer: summary.payer_route === 'unknown' ? 'unknown' : summary.payer_route }));
    }
    if (sets.length === 0) return publicView(summary);

    await db.query(`UPDATE incidents SET ${sets.join(', ')} WHERE id = ?`, [...params, incidentId]);

    const updated = await broadcast(incidentId);
    if (updated?.hospital_id) {
        await logActivity({
            hospitalId: updated.hospital_id, action: 'incident.updated', entityType: 'incident', entityId: incidentId,
            summary: `Caller added details to request #${incidentId}`
        });
    }
    return publicView(updated);
}

// The citizen cancels their own request (false alarm, or they found other transport).
async function cancelPublicIncident(publicUser, incidentId, reason) {
    const summary = await getSummary(incidentId);
    if (!summary || summary.public_user_id !== publicUser.id) throw new DispatchError(404, 'Request not found');
    if (!ACTIVE_STATUSES.includes(summary.status) && summary.status !== 'unplaced') {
        throw new DispatchError(409, 'This request can no longer be cancelled.');
    }

    const [res] = await db.query(`
        UPDATE incidents SET status = 'cancelled', cancelled_at = ?, cancel_reason = ?
        WHERE id = ? AND status IN ('requested', 'accepted', 'picked_up', 'arrived', 'unplaced')`,
        [new Date(), (reason || 'Cancelled by the caller').slice(0, 255), incidentId]);
    if (!res.affectedRows) throw new DispatchError(409, 'This request can no longer be cancelled.');

    const [pending] = await db.query("SELECT id, hospital_id FROM incident_requests WHERE incident_id = ? AND status IN ('pending', 'queued')", [incidentId]);
    await db.query("UPDATE incident_requests SET status = 'cancelled' WHERE incident_id = ? AND status IN ('pending', 'queued')", [incidentId]);
    for (const p of pending) {
        emitToHospitals(p.hospital_id, 'incident_request_closed', { incident_id: incidentId, request_id: p.id, outcome: 'cancelled' });
    }
    await closeMissedRequests(incidentId, 'cancelled');

    await releaseHolds(incidentId);
    await closeOffers(incidentId, 'cancelled');
    await freeAmbulance(summary.ambulance_id);

    const updated = await broadcast(incidentId);
    if (updated?.hospital_id) {
        await logActivity({
            hospitalId: updated.hospital_id, action: 'incident.cancelled', entityType: 'incident', entityId: incidentId,
            summary: `Public request #${incidentId} cancelled by the caller${reason ? ` (${reason})` : ''}`
        });
    }
    return publicView(updated);
}

// Active public requests near a hospital, for its control-room view.
async function publicRequestsNear(hospitalId, radiusKm = 50) {
    const [rows] = await db.query(`
        SELECT i.id FROM incidents i
        JOIN hospitals me ON me.id = ?
        WHERE i.source = 'public'
          AND i.status IN ('requested', 'accepted', 'picked_up', 'arrived', 'unplaced')
          AND ST_Distance_Sphere(POINT(i.patient_lng, i.patient_lat), POINT(me.longitude, me.latitude)) / 1000 <= ?
        ORDER BY i.dispatched_at DESC LIMIT 50`, [hospitalId, radiusKm]);
    const out = [];
    for (const r of rows) out.push(await getSummary(r.id));
    return out;
}

// Asks every candidate hospital at once, on one shared deadline.
async function askAll(incidentId) {
    const [[inc]] = await db.query('SELECT status FROM incidents WHERE id = ?', [incidentId]);
    if (!inc || inc.status !== 'requested') return;

    const [queued] = await db.query(
        "SELECT id, hospital_id, rank_order FROM incident_requests WHERE incident_id = ? AND status = 'queued' ORDER BY rank_order",
        [incidentId]
    );
    if (!queued.length) return settleIfAllAnswered(incidentId);

    const now = new Date();
    const expires = new Date(now.getTime() + REQUEST_TIMEOUT_SECONDS * 1000);
    await db.query(
        "UPDATE incident_requests SET status = 'pending', sent_at = ?, expires_at = ? WHERE incident_id = ? AND status = 'queued'",
        [now, expires, incidentId]
    );
    await setDestination(incidentId, queued[0].hospital_id);

    const [[{ asked }]] = await db.query('SELECT COUNT(*) AS asked FROM incident_requests WHERE incident_id = ?', [incidentId]);
    const summary = await getSummary(incidentId);
    for (const q of queued) {
        emitToHospitals(q.hospital_id, 'incident_request',
            requestPayload(summary, { id: q.id, expires_at: expires, rank_order: q.rank_order, asked_count: asked }));
    }
    emitIncident(summary);
}

// The ambulance must not keep heading for a hospital that has said no. Point it at
// the best-ranked hospital still deciding.
async function retarget(incidentId) {
    const [[inc]] = await db.query('SELECT status, hospital_id FROM incidents WHERE id = ?', [incidentId]);
    if (!inc || inc.status !== 'requested') return;
    const [[next]] = await db.query(
        "SELECT hospital_id FROM incident_requests WHERE incident_id = ? AND status = 'pending' ORDER BY rank_order LIMIT 1",
        [incidentId]
    );
    if (!next || next.hospital_id === inc.hospital_id) return;

    await setDestination(incidentId, next.hospital_id);
    const summary = await broadcast(incidentId);
}

// Nobody is left to answer. Unlike the old sequential flow there is no next hospital
// to fall back to: they have all already been asked.
async function settleIfAllAnswered(incidentId) {
    const [[{ open }]] = await db.query(
        "SELECT COUNT(*) AS open FROM incident_requests WHERE incident_id = ? AND status IN ('pending', 'queued')",
        [incidentId]
    );
    if (open) return;

    const [res] = await db.query("UPDATE incidents SET status = 'unplaced' WHERE id = ? AND status = 'requested'", [incidentId]);
    if (!res.affectedRows) return;

    const summary = await broadcast(incidentId);
    await logActivity({
        hospitalId: summary.requested_by_hospital_id, action: 'incident.unplaced', entityType: 'incident', entityId: incidentId,
        summary: `Dispatch #${incidentId}: none of the hospitals asked accepted. Search again or cancel.`
    });
}

// Unplaced incident: the dispatcher picked more hospitals to try.
async function addCandidates(user, incidentId, hospitalIds) {
    const summary = await getSummary(incidentId);
    if (!summary || summary.requested_by_hospital_id !== user.hospital_id) throw new DispatchError(404, 'Incident not found');
    if (summary.status !== 'unplaced') throw new DispatchError(409, 'This incident is not waiting for a hospital.');

    const [[{ maxRank }]] = await db.query('SELECT COALESCE(MAX(rank_order), 0) AS maxRank FROM incident_requests WHERE incident_id = ?', [incidentId]);
    for (const [i, hospitalId] of [...new Set(hospitalIds)].slice(0, DISPATCH_FANOUT).entries()) {
        await db.query('INSERT INTO incident_requests (incident_id, hospital_id, rank_order) VALUES (?, ?, ?)', [incidentId, hospitalId, maxRank + i + 1]);
    }
    await db.query("UPDATE incidents SET status = 'requested' WHERE id = ?", [incidentId]);
    await askAll(incidentId);
    return getDetail(incidentId);
}

// ---------------- Hospital response ---------------- //

async function pendingRequestFor(incidentId, hospitalId) {
    const [[request]] = await db.query(
        "SELECT id, hospital_id FROM incident_requests WHERE incident_id = ? AND hospital_id = ? AND status = 'pending'",
        [incidentId, hospitalId]
    );
    if (!request) throw new DispatchError(409, 'This request is no longer waiting for your hospital.');
    return request;
}

// The live request for this hospital, or one it missed (timed out). A missed request
// can still be accepted as long as no hospital has taken the patient.
async function acceptableRequestFor(incidentId, hospitalId) {
    const [[request]] = await db.query(`
        SELECT r.id, r.status, r.rank_order FROM incident_requests r
        JOIN incidents i ON i.id = r.incident_id
        WHERE r.incident_id = ? AND r.hospital_id = ?
          AND (r.status = 'pending' OR (r.status = 'expired' AND i.status IN ('requested', 'unplaced')))
        ORDER BY r.status = 'pending' DESC LIMIT 1`, [incidentId, hospitalId]);
    if (!request) throw new DispatchError(409, 'This patient has already been accepted by another hospital, or the dispatch was cancelled.');
    return request;
}

// Picks who receives the patient: a specialist for the complaint first, then Emergency/Trauma.
async function pickReceivingDoctor(hospitalId, complaint) {
    const departments = complaintByCode(complaint).departments;
    const [[doc]] = await db.query(`
        SELECT doc.id FROM doctors doc
        JOIN departments d ON d.id = doc.department_id
        WHERE doc.hospital_id = ? AND doc.status IN ('on_duty', 'on_call') AND (d.name IN (?) OR d.name IN (?))
        ORDER BY d.name IN (?) DESC, doc.status = 'on_duty' DESC, d.name = 'Emergency' DESC
        LIMIT 1`, [hospitalId, inList(departments), EMERGENCY_DEPARTMENTS, inList(departments)]);
    return doc ? doc.id : null;
}

async function holdOne(incidentId, hospitalId, type, departments) {
    const [[resource]] = await db.query(`
        SELECT r.id FROM hospital_resources r
        JOIN resource_types rt ON rt.id = r.resource_type_id
        JOIN departments d ON d.id = r.department_id
        WHERE r.hospital_id = ? AND rt.name = ? AND r.current_count > 0
        ORDER BY d.name IN (?) DESC, d.name = 'Emergency' DESC, r.current_count DESC
        LIMIT 1`, [hospitalId, type, inList(departments)]);
    if (!resource) return false;

    const [updated] = await db.query('UPDATE hospital_resources SET current_count = current_count - 1 WHERE id = ? AND current_count > 0', [resource.id]);
    if (!updated.affectedRows) return false;
    await db.query("INSERT INTO bed_holds (incident_id, resource_id, status, created_at) VALUES (?, ?, 'held', ?)", [incidentId, resource.id, new Date()]);
    await emitResource(resource.id, hospitalId);
    return true;
}

async function emitResource(resourceId, hospitalId) {
    const [[r]] = await db.query('SELECT current_count, capacity FROM hospital_resources WHERE id = ?', [resourceId]);
    emitToHospitals(hospitalId, 'resource_updated', { id: resourceId, newValue: r.current_count, capacity: r.capacity });
}

/**
 * Decides who gets the patient when several hospitals accept at once.
 *
 * Every hospital was asked at the same moment, so two acceptances can land
 * milliseconds apart. Letting the faster click win would send the patient to
 * whichever hospital has the quickest receptionist, which is not the same as the
 * hospital they should go to. So an acceptance from anyone but the best-ranked
 * hospital registers a claim and pauses briefly; whoever the ranking preferred
 * then wins the window.
 *
 * The best-ranked hospital never waits: nothing could outrank it.
 */
async function winRace(incidentId, request, user) {
    const [mine] = await db.query(
        "UPDATE incident_requests SET claimed_at = ?, claimed_by = ? WHERE id = ? AND status = 'pending' AND claimed_at IS NULL",
        [new Date(), user.id, request.id]
    );
    if (!mine.affectedRows) throw new DispatchError(409, 'Someone at your hospital is already answering this request.');

    const [[{ better }]] = await db.query(
        `SELECT COUNT(*) AS better FROM incident_requests
         WHERE incident_id = ? AND status = 'pending' AND rank_order < ? AND claimed_at IS NULL`,
        [incidentId, request.rank_order]
    );
    if (!better) return;

    await sleep(CLAIM_WINDOW_MS);

    const [[winner]] = await db.query(
        `SELECT id FROM incident_requests
         WHERE incident_id = ? AND status = 'pending' AND claimed_at IS NOT NULL
         ORDER BY rank_order LIMIT 1`,
        [incidentId]
    );
    if (winner && winner.id !== request.id) {
        await db.query('UPDATE incident_requests SET claimed_at = NULL, claimed_by = NULL WHERE id = ?', [request.id]);
        throw new DispatchError(409, 'Another hospital better suited to this patient accepted at the same moment.');
    }
}

async function accept(user, incidentId) {
    const request = await acceptableRequestFor(incidentId, user.hospital_id);
    const late = request.status === 'expired';
    // A late acceptance has no race to win: every other hospital's deadline has passed too.
    if (!late) await winRace(incidentId, request, user);
    const now = new Date();

    const [[inc]] = await db.query('SELECT complaint, needs_icu, patient_lat, patient_lng FROM incidents WHERE id = ?', [incidentId]);
    const [[hospital]] = await db.query('SELECT latitude, longitude FROM hospitals WHERE id = ?', [user.hospital_id]);
    const distance = haversineKm(Number(inc.patient_lat), Number(inc.patient_lng), Number(hospital.latitude), Number(hospital.longitude));
    const doctorId = await pickReceivingDoctor(user.hospital_id, inc.complaint);

    // Claiming the incident itself is the race: the first hospital to accept wins.
    const [claimed] = await db.query(`
        UPDATE incidents
        SET status = IF(picked_up_at IS NULL, 'accepted', 'picked_up'), accepted_at = ?, receiving_doctor_id = ?,
            hospital_id = ?, distance_km = ?
        WHERE id = ? AND status IN ('requested', 'unplaced')`,
        [now, doctorId, user.hospital_id, distance.toFixed(2), incidentId]);
    if (!claimed.affectedRows) throw new DispatchError(409, 'Another hospital has already accepted this patient.');

    await db.query(
        "UPDATE incident_requests SET status = 'accepted', responded_by = ?, responded_at = ?, reason = ? WHERE id = ?",
        [user.id, now, late ? 'Accepted after the timer ran out' : null, request.id]
    );

    // Whoever is still being asked no longer needs to answer.
    const [stillOpen] = await db.query(
        "SELECT id, hospital_id FROM incident_requests WHERE incident_id = ? AND status = 'pending'", [incidentId]
    );
    await db.query("UPDATE incident_requests SET status = 'cancelled' WHERE incident_id = ? AND status IN ('pending', 'queued')", [incidentId]);
    for (const r of stillOpen) {
        emitToHospitals(r.hospital_id, 'incident_request_closed', { incident_id: incidentId, request_id: r.id, outcome: 'taken' });
    }
    await closeMissedRequests(incidentId, 'taken', user.hospital_id);

    // Hold a bed (and an ICU bed if needed) so it isn't given to someone else on the way.
    const departments = complaintByCode(inc.complaint).departments;
    const bedHeld = await holdOne(incidentId, user.hospital_id, 'Beds', departments);
    const icuHeld = inc.needs_icu ? await holdOne(incidentId, user.hospital_id, 'ICU', departments) : null;

    emitToHospitals(user.hospital_id, 'incident_request_closed', { incident_id: incidentId, request_id: request.id, outcome: 'accepted', by: user.name });

    const summary = await broadcast(incidentId);
    await logActivity({
        hospitalId: user.hospital_id, user, action: 'incident.accepted', entityType: 'incident', entityId: incidentId,
        summary: `Accepted${late ? ' (after the timer ran out)' : ''} incoming patient #${incidentId} (${summary.complaint_label}) from ${summary.requested_by_hospital_name}`
            + `${bedHeld ? ', bed held' : ', no free bed to hold'}${icuHeld === false ? ', no ICU bed to hold' : icuHeld ? ', ICU bed held' : ''}`
    });

    const warnings = [];
    if (!bedHeld) warnings.push('No free bed was recorded, so none could be held.');
    if (icuHeld === false) warnings.push('No free ICU bed was recorded, so none could be held.');
    return { incident: await getDetail(incidentId), warnings };
}

async function divert(user, incidentId, reasonCode, note) {
    const request = await pendingRequestFor(incidentId, user.hospital_id);
    const label = (DIVERT_REASONS.find(r => r.code === reasonCode) || DIVERT_REASONS[DIVERT_REASONS.length - 1]).label;
    const reason = note ? `${label}: ${note}` : label;

    const [claimed] = await db.query(
        "UPDATE incident_requests SET status = 'diverted', reason = ?, responded_by = ?, responded_at = ? WHERE id = ? AND status = 'pending'",
        [reason.slice(0, 255), user.id, new Date(), request.id]
    );
    if (!claimed.affectedRows) throw new DispatchError(409, 'Someone at your hospital already answered this request.');

    emitToHospitals(user.hospital_id, 'incident_request_closed', { incident_id: incidentId, request_id: request.id, outcome: 'diverted', by: user.name });
    await logActivity({
        hospitalId: user.hospital_id, user, action: 'incident.diverted', entityType: 'incident', entityId: incidentId,
        summary: `Diverted incoming patient #${incidentId} (${reason})`
    });
    // The other hospitals were asked at the same time; there is no next one to try.
    await retarget(incidentId);
    await settleIfAllAnswered(incidentId);
}

// Requests nobody answered in time count as diverted ("No response").
async function sweepExpired() {
    try {
        // A claim whose request died before it could be resolved -- a crash, or a
        // failure between claiming and accepting -- would otherwise lock that
        // hospital out of a patient it is still allowed to take.
        await db.query(
            "UPDATE incident_requests SET claimed_at = NULL, claimed_by = NULL WHERE status = 'pending' AND claimed_at < ?",
            [new Date(Date.now() - CLAIM_WINDOW_MS * 5)]
        );

        const [expired] = await db.query(
            "SELECT id, incident_id, hospital_id FROM incident_requests WHERE status = 'pending' AND expires_at <= ?",
            [new Date()]
        );
        for (const r of expired) {
            const [res] = await db.query(
                "UPDATE incident_requests SET status = 'expired', reason = 'No response in time', responded_at = ? WHERE id = ? AND status = 'pending'",
                [new Date(), r.id]
            );
            if (!res.affectedRows) continue;
            emitToHospitals(r.hospital_id, 'incident_request_closed', { incident_id: r.incident_id, request_id: r.id, outcome: 'expired' });
            await logActivity({
                hospitalId: r.hospital_id, action: 'incident.expired', entityType: 'incident', entityId: r.incident_id,
                summary: `Incoming patient #${r.incident_id} wasn't answered within ${REQUEST_TIMEOUT_SECONDS}s. It can still be accepted until another hospital takes the patient.`
            });
        }
        await sweepOffers();
        // One deadline is shared by every hospital asked, so they expire together.
        for (const incidentId of new Set(expired.map(r => r.incident_id))) {
            await settleIfAllAnswered(incidentId);
        }
    } catch (err) {
        console.error('Dispatch sweeper error:', err.message);
    }
}

// ---------------- Lifecycle ---------------- //

async function releaseHolds(incidentId) {
    const [holds] = await db.query(`
        SELECT b.id, b.resource_id, r.hospital_id FROM bed_holds b
        JOIN hospital_resources r ON r.id = b.resource_id
        WHERE b.incident_id = ? AND b.status = 'held'`, [incidentId]);
    for (const h of holds) {
        await db.query("UPDATE bed_holds SET status = 'released', updated_at = ? WHERE id = ?", [new Date(), h.id]);
        await db.query('UPDATE hospital_resources SET current_count = current_count + 1 WHERE id = ?', [h.resource_id]);
        await emitResource(h.resource_id, h.hospital_id);
    }
}

async function freeAmbulance(ambulanceId) {
    if (ambulanceId) await db.query("UPDATE ambulances SET status = 'available' WHERE id = ?", [ambulanceId]);
}

async function cancel(user, incidentId, reason) {
    const summary = await getSummary(incidentId);
    if (!summary || !involves(summary, user.hospital_id)) throw new DispatchError(404, 'Incident not found');
    // The requesting hospital can always cancel; the receiving one only after accepting.
    const canCancel = summary.requested_by_hospital_id === user.hospital_id || (summary.hospital_id === user.hospital_id && summary.accepted_at);
    if (!canCancel) throw new DispatchError(403, 'Divert the request instead of cancelling it.');
    if (!ACTIVE_STATUSES.includes(summary.status) && summary.status !== 'unplaced') {
        throw new DispatchError(409, 'This incident can no longer be cancelled.');
    }

    const [res] = await db.query(`
        UPDATE incidents SET status = 'cancelled', cancelled_at = ?, cancel_reason = ?, cancelled_by = ?
        WHERE id = ? AND status IN ('requested', 'accepted', 'picked_up', 'arrived', 'unplaced')`,
        [new Date(), reason || null, user.id, incidentId]);
    if (!res.affectedRows) throw new DispatchError(409, 'This incident can no longer be cancelled.');

    const [pending] = await db.query("SELECT id, hospital_id FROM incident_requests WHERE incident_id = ? AND status IN ('pending', 'queued')", [incidentId]);
    await db.query("UPDATE incident_requests SET status = 'cancelled' WHERE incident_id = ? AND status IN ('pending', 'queued')", [incidentId]);
    for (const p of pending) {
        emitToHospitals(p.hospital_id, 'incident_request_closed', { incident_id: incidentId, request_id: p.id, outcome: 'cancelled' });
    }
    await closeMissedRequests(incidentId, 'cancelled');

    await releaseHolds(incidentId);
    await closeOffers(incidentId, 'cancelled');
    await freeAmbulance(summary.ambulance_id);

    await broadcast(incidentId);
    const text = `Cancelled dispatch #${incidentId}${reason ? ` (${reason})` : ''}`;
    for (const hospitalId of new Set(roomsFor(summary))) {
        await logActivity({ hospitalId, user: hospitalId === user.hospital_id ? user : null, action: 'incident.cancelled', entityType: 'incident', entityId: incidentId, summary: text });
    }
    return getDetail(incidentId);
}

async function handOver(user, incidentId) {
    const summary = await getSummary(incidentId);
    if (!summary || summary.hospital_id !== user.hospital_id || !summary.accepted_at) throw new DispatchError(404, 'Incident not found');
    if (!['accepted', 'picked_up', 'arrived'].includes(summary.status)) throw new DispatchError(409, 'This patient has already been handed over or the incident is closed.');

    const now = new Date();
    await db.query(
        "UPDATE incidents SET status = 'handed_over', handed_over_at = ?, arrived_at = COALESCE(arrived_at, ?), picked_up_at = COALESCE(picked_up_at, ?) WHERE id = ?",
        [now, now, now, incidentId]
    );
    await db.query("UPDATE bed_holds SET status = 'used', updated_at = ? WHERE incident_id = ? AND status = 'held'", [now, incidentId]);

    // A demo ambulance has no driver to report where it ended up; it is at the hospital.
    await db.query("UPDATE ambulances SET latitude = ?, longitude = ? WHERE id = ? AND location_source = 'demo'",
        [summary.hospital_lat, summary.hospital_lng, summary.ambulance_id]);
    await closeOffers(incidentId, 'cancelled');
    await freeAmbulance(summary.ambulance_id);

    await broadcast(incidentId);
    await logActivity({
        hospitalId: user.hospital_id, user, action: 'incident.handed_over', entityType: 'incident', entityId: incidentId,
        summary: `Patient from dispatch #${incidentId} handed over${summary.receiving_doctor_name ? ` to ${summary.receiving_doctor_name}` : ''}`
    });
    return getDetail(incidentId);
}

async function close(user, incidentId) {
    const summary = await getSummary(incidentId);
    if (!summary || !involves(summary, user.hospital_id)) throw new DispatchError(404, 'Incident not found');
    const [res] = await db.query("UPDATE incidents SET status = 'closed', closed_at = ? WHERE id = ? AND status = 'handed_over'", [new Date(), incidentId]);
    if (!res.affectedRows) throw new DispatchError(409, 'Only incidents that have been handed over can be closed.');
    await broadcast(incidentId);
    return getDetail(incidentId);
}

// ---------------- Finding a driver ---------------- //

// What a driver sees in the offer: enough to decide in a few seconds.
const offerPayload = (summary, offer, offeredCount) => ({
    offer_id: offer.id,
    incident_id: summary.id,
    expires_at: offer.expires_at,
    timeout_seconds: OFFER_SECONDS,
    distance_km: Number(offer.distance_km),
    rank_order: offer.rank_order,
    offered_count: offeredCount,
    severity: summary.severity,
    needs_icu: summary.needs_icu,
    complaint_label: summary.complaint_label,
    pickup_address: summary.pickup_address,
    patient_lat: summary.patient_lat,
    patient_lng: summary.patient_lng,
    hospital_name: summary.hospital_name,
    hospital_lat: summary.hospital_lat,
    hospital_lng: summary.hospital_lng,
    source: summary.source
});

/**
 * Offers the job to the nearest drivers who haven't been asked about it yet.
 * Returns how many were asked (0 when there is nobody left, which ends the search).
 */
async function offerAmbulance(incidentId) {
    const [[inc]] = await db.query('SELECT status, ambulance_id, patient_lat, patient_lng FROM incidents WHERE id = ?', [incidentId]);
    if (!inc || inc.ambulance_id || !OFFERABLE_STATUSES.includes(inc.status)) return 0;

    const [[{ round }]] = await db.query('SELECT COALESCE(MAX(round), 0) AS round FROM ambulance_offers WHERE incident_id = ?', [incidentId]);
    if (round >= OFFER_ROUNDS) { await giveUpOnDriver(incidentId); return 0; }

    // Nearest first. Skip anyone already asked about this patient, and anyone who is
    // deciding on another job right now -- one offer per driver at a time.
    const f = dispatchableAmbulances('a');
    const [candidates] = await db.query(`
        SELECT a.id, a.location_source, a.current_driver_id,
               ST_Distance_Sphere(POINT(a.longitude, a.latitude), POINT(?, ?)) / 1000 AS distance_km
        FROM ambulances a
        WHERE ${f.sql}
          AND NOT EXISTS (SELECT 1 FROM ambulance_offers o WHERE o.ambulance_id = a.id AND (o.status = 'pending' OR o.incident_id = ?))
        ORDER BY distance_km LIMIT ?`,
        [Number(inc.patient_lng), Number(inc.patient_lat), ...f.params, incidentId, OFFER_FANOUT]);
    if (!candidates.length) { await giveUpOnDriver(incidentId); return 0; }

    const now = new Date();
    const expires = new Date(now.getTime() + OFFER_SECONDS * 1000);
    const offers = [];
    for (const [i, a] of candidates.entries()) {
        const driverId = a.location_source === 'gps' ? a.current_driver_id : null;
        const [r] = await db.query(`
            INSERT INTO ambulance_offers (incident_id, ambulance_id, driver_id, round, rank_order, distance_km, sent_at, expires_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [incidentId, a.id, driverId, round + 1, i + 1, Number(a.distance_km).toFixed(2), now, expires]);
        offers.push({ id: r.insertId, driver_id: driverId, rank_order: i + 1, distance_km: a.distance_km, expires_at: expires });
    }
    await db.query("UPDATE incidents SET ambulance_search = 'searching' WHERE id = ? AND ambulance_id IS NULL", [incidentId]);

    const summary = await broadcast(incidentId);
    for (const o of offers) {
        if (o.driver_id) emitToUser(o.driver_id, 'ambulance_offer', offerPayload(summary, o, offers.length));
    }
    return offers.length;
}

async function giveUpOnDriver(incidentId) {
    const [r] = await db.query("UPDATE incidents SET ambulance_search = 'failed' WHERE id = ? AND ambulance_id IS NULL", [incidentId]);
    if (!r.affectedRows) return;
    const summary = await broadcast(incidentId);
    await logActivity({
        hospitalId: summary?.requested_by_hospital_id || summary?.hospital_id, action: 'incident.no_ambulance', entityType: 'incident', entityId: incidentId,
        summary: `Dispatch #${incidentId}: no ambulance driver accepted. Call ${process.env.EMERGENCY_NUMBER || '108'}.`
    });
}

// Ends every live offer for an incident and tells the drivers concerned.
async function closeOffers(incidentId, outcome, exceptOfferId = null) {
    const [open] = await db.query("SELECT id, driver_id FROM ambulance_offers WHERE incident_id = ? AND status = 'pending'", [incidentId]);
    for (const o of open) {
        if (o.id === exceptOfferId) continue;
        await db.query("UPDATE ambulance_offers SET status = 'cancelled', responded_at = ? WHERE id = ? AND status = 'pending'", [new Date(), o.id]);
        if (o.driver_id) emitToUser(o.driver_id, 'ambulance_offer_closed', { offer_id: o.id, incident_id: incidentId, outcome });
    }
}

// Everyone asked in this round has answered no (or not at all): ask the next nearest.
async function afterOfferAnswered(incidentId) {
    const [[{ open }]] = await db.query("SELECT COUNT(*) AS open FROM ambulance_offers WHERE incident_id = ? AND status = 'pending'", [incidentId]);
    if (!open) await offerAmbulance(incidentId);
}

/**
 * A driver (or, for a demo ambulance, the simulator) accepts an offer.
 * `by`: { driverId } for a driver, { demo: true } for the simulator.
 */
async function acceptOffer(offerId, by) {
    const [[offer]] = await db.query('SELECT * FROM ambulance_offers WHERE id = ?', [offerId]);
    const mine = offer && (by.demo ? offer.driver_id === null : offer.driver_id === by.driverId);
    if (!mine) throw new DispatchError(404, 'Job offer not found.');
    if (offer.status !== 'pending') throw new DispatchError(409, 'This job has already been taken, cancelled or has expired.');

    // Same rule as hospitals: the nearest driver never waits; anyone further away
    // pauses briefly so a nearer driver accepting at the same moment wins.
    const [claimed] = await db.query(
        "UPDATE ambulance_offers SET claimed_at = ? WHERE id = ? AND status = 'pending' AND claimed_at IS NULL", [new Date(), offerId]);
    if (!claimed.affectedRows) throw new DispatchError(409, 'You already accepted this job.');
    const [[{ nearer }]] = await db.query(`
        SELECT COUNT(*) AS nearer FROM ambulance_offers
        WHERE incident_id = ? AND status = 'pending' AND rank_order < ? AND claimed_at IS NULL`, [offer.incident_id, offer.rank_order]);
    if (nearer) {
        await sleep(CLAIM_WINDOW_MS);
        // A nearer driver may have taken the job outright while we waited.
        const [[me]] = await db.query('SELECT status FROM ambulance_offers WHERE id = ?', [offerId]);
        if (me.status !== 'pending') throw new DispatchError(409, 'A nearer ambulance accepted this job at the same moment.');
        const [[winner]] = await db.query(`
            SELECT id FROM ambulance_offers WHERE incident_id = ? AND status = 'pending' AND claimed_at IS NOT NULL
            ORDER BY rank_order LIMIT 1`, [offer.incident_id]);
        if (winner && winner.id !== offerId) {
            await db.query('UPDATE ambulance_offers SET claimed_at = NULL WHERE id = ?', [offerId]);
            throw new DispatchError(409, 'A nearer ambulance accepted this job at the same moment.');
        }
    }

    // Take the ambulance, then the job. Either can fail if something changed meanwhile.
    const [took] = await db.query("UPDATE ambulances SET status = 'dispatched' WHERE id = ? AND status = 'available'", [offer.ambulance_id]);
    if (!took.affectedRows) {
        await db.query("UPDATE ambulance_offers SET status = 'cancelled', responded_at = ? WHERE id = ?", [new Date(), offerId]);
        await afterOfferAnswered(offer.incident_id);
        throw new DispatchError(409, 'Your ambulance is no longer available (off shift or on another job).');
    }
    const [job] = await db.query(`
        UPDATE incidents SET ambulance_id = ?, ambulance_search = 'assigned'
        WHERE id = ? AND ambulance_id IS NULL AND status IN (?)`, [offer.ambulance_id, offer.incident_id, OFFERABLE_STATUSES]);
    if (!job.affectedRows) {
        await freeAmbulance(offer.ambulance_id);
        await db.query("UPDATE ambulance_offers SET status = 'cancelled', responded_at = ? WHERE id = ?", [new Date(), offerId]);
        throw new DispatchError(409, 'Another ambulance has already taken this job, or it was cancelled.');
    }

    await db.query("UPDATE ambulance_offers SET status = 'accepted', responded_at = ? WHERE id = ?", [new Date(), offerId]);
    await closeOffers(offer.incident_id, 'taken', offerId);

    const summary = await broadcast(offer.incident_id);
    await logActivity({
        hospitalId: summary.requested_by_hospital_id || summary.hospital_id, action: 'incident.ambulance_accepted',
        entityType: 'incident', entityId: offer.incident_id,
        summary: `${summary.ambulance_vehicle || summary.ambulance_name} accepted dispatch #${offer.incident_id}, ${Number(offer.distance_km)} km from the patient`
    });
    return summary;
}

async function declineOffer(offerId, driverId) {
    const [[offer]] = await db.query('SELECT incident_id FROM ambulance_offers WHERE id = ? AND driver_id = ?', [offerId, driverId]);
    if (!offer) throw new DispatchError(404, 'Job offer not found.');
    const [r] = await db.query(
        "UPDATE ambulance_offers SET status = 'declined', responded_at = ? WHERE id = ? AND status = 'pending'", [new Date(), offerId]);
    if (!r.affectedRows) throw new DispatchError(409, 'This job is no longer waiting for you.');
    await afterOfferAnswered(offer.incident_id);
}

// Offers nobody answered in time count as declined; then the next nearest are asked.
async function sweepOffers() {
    await db.query("UPDATE ambulance_offers SET claimed_at = NULL WHERE status = 'pending' AND claimed_at < ?",
        [new Date(Date.now() - CLAIM_WINDOW_MS * 5)]);
    const [expired] = await db.query(
        "SELECT id, incident_id, driver_id FROM ambulance_offers WHERE status = 'pending' AND expires_at <= ?", [new Date()]);
    for (const o of expired) {
        const [r] = await db.query("UPDATE ambulance_offers SET status = 'expired', responded_at = ? WHERE id = ? AND status = 'pending'", [new Date(), o.id]);
        if (r.affectedRows && o.driver_id) emitToUser(o.driver_id, 'ambulance_offer_closed', { offer_id: o.id, incident_id: o.incident_id, outcome: 'expired' });
    }
    for (const incidentId of new Set(expired.map(o => o.incident_id))) await afterOfferAnswered(incidentId);
}

// Live offers for one driver (on reload) or for the demo fleet (the simulator).
async function pendingOffers({ driverId = null, demo = false }) {
    const [rows] = await db.query(`
        SELECT o.*, (SELECT COUNT(*) FROM ambulance_offers c WHERE c.incident_id = o.incident_id AND c.round = o.round) AS offered_count
        FROM ambulance_offers o
        WHERE o.status = 'pending' AND o.expires_at > ? AND ${demo ? 'o.driver_id IS NULL' : 'o.driver_id = ?'}
        ORDER BY o.sent_at`, demo ? [new Date()] : [new Date(), driverId]);
    const out = [];
    for (const o of rows) {
        const summary = await getSummary(o.incident_id);
        if (summary) out.push({ ...offerPayload(summary, o, o.offered_count), ambulance_id: o.ambulance_id });
    }
    return out;
}

// ---------------- Ambulance positions ---------------- //

// Where the ambulance should be heading, derived from the incident alone.
//   to_patient  : nobody has been picked up yet
//   to_hospital : patient on board and a hospital has accepted
//   waiting     : patient on board, no hospital yet -- or already at the hospital
const legOf = (summary) => !summary.picked_up_at ? 'to_patient'
    : ['accepted', 'picked_up'].includes(summary.status) ? 'to_hospital' : 'waiting';

const targetOf = (summary, leg) => leg === 'to_patient'
    ? [Number(summary.patient_lat), Number(summary.patient_lng)]
    : [Number(summary.hospital_lat), Number(summary.hospital_lng)];

function emitLocation(summary, payload) {
    emitToHospitals(roomsFor(summary), 'ambulance_location_update', payload);
    emitToUser(summary.ambulance_driver_id, 'ambulance_location_update', payload);
}

/**
 * Something reported where an ambulance is. The caller has already saved the
 * position; this tells everyone watching the job and detects arrival.
 */
async function reportPosition(ambulanceId, lat, lng) {
    const job = await activeJobForAmbulance(ambulanceId);
    if (!job) return null;

    const leg = legOf(job);
    if (leg === 'waiting') {
        emitLocation(job, { incident_id: job.id, lat, lng, leg, eta_seconds: null });
        return job;
    }

    const target = targetOf(job, leg);
    const { route, version, changed } = await routing.routeFor(job.id, leg, [lat, lng], target);
    if (changed) await emitRoute(job, leg, route, version);
    const p = routing.progressFor(job.id, route, [lat, lng]);
    emitLocation(job, {
        incident_id: job.id, lat, lng, leg,
        eta_seconds: p.eta_seconds, remaining_km: Number(p.remaining_km.toFixed(2)),
        eta_source: route.source, route_version: version
    });

    // Arrived: close to the pin, or at the end of the road route. A route ends where
    // the road does, which for a hospital campus can be some way from its map pin.
    const radius = leg === 'to_patient' ? ARRIVE_PATIENT_KM : ARRIVE_HOSPITAL_KM;
    const atPin = haversineKm(lat, lng, target[0], target[1]) <= radius;
    const atRouteEnd = route.source !== 'estimate' && p.remaining_km <= radius;
    if (!atPin && !atRouteEnd) return job;
    return leg === 'to_patient' ? arrivePatient(job.id) : arriveHospital(job.id);
}

// The road from the patient to the hospital, shown while the ambulance is still on
// its way to the patient so everyone sees the whole journey. Fixed at both ends, so
// it is fetched once per hospital and then served from the cache.
async function aheadFor(job, leg) {
    if (leg !== 'to_patient' || job.hospital_lat === null) return null;
    const patient = [Number(job.patient_lat), Number(job.patient_lng)];
    const { route } = await routing.routeFor(`${job.id}:ahead`, 'ahead', patient, [Number(job.hospital_lat), Number(job.hospital_lng)]);
    return { geometry: route.geometry, distance_km: Number(route.distance_km.toFixed(2)), duration_s: Math.round(route.duration_s), source: route.source };
}

// The road route for a leg, sent once when it changes rather than with every position.
async function emitRoute(summary, leg, route, version) {
    const payload = { ...routePayload(summary.id, leg, route, version), ahead: await aheadFor(summary, leg) };
    emitToHospitals(roomsFor(summary), 'ambulance_route', payload);
    emitToUser(summary.ambulance_driver_id, 'ambulance_route', payload);
}

const routePayload = (incidentId, leg, route, version) => ({
    incident_id: incidentId, leg, version,
    geometry: route.geometry,
    distance_km: Number(route.distance_km.toFixed(2)),
    duration_s: Math.round(route.duration_s),
    source: route.source,
    traffic: route.traffic
});

/**
 * The current leg's route and ETA, for a map opening the incident. Fetches a route
 * if there isn't one yet. null when the ambulance has nowhere to go right now.
 */
async function routeView(incidentId) {
    const job = await getSummary(incidentId);
    if (!job || !['requested', 'accepted', 'picked_up', 'unplaced'].includes(job.status)) return null;
    if (job.ambulance_lat === null) {
        const ahead = await aheadFor(job, 'to_patient');
        return ahead ? { incident_id: job.id, leg: null, geometry: null, ahead } : null;
    }
    const leg = legOf(job);
    if (leg === 'waiting') return null;
    const pos = [Number(job.ambulance_lat), Number(job.ambulance_lng)];
    const { route, version } = await routing.routeFor(job.id, leg, pos, targetOf(job, leg));
    const p = routing.progressFor(job.id, route, pos, false);
    return { ...routePayload(job.id, leg, route, version), eta_seconds: p.eta_seconds, remaining_km: Number(p.remaining_km.toFixed(2)),
        ahead: await aheadFor(job, leg) };
}

// The ambulance reached the patient (reported position, or the driver tapped "Picked up").
async function arrivePatient(incidentId) {
    await db.query(
        "UPDATE incidents SET picked_up_at = ?, status = IF(status = 'accepted', 'picked_up', status) WHERE id = ? AND picked_up_at IS NULL",
        [new Date(), incidentId]
    );
    return broadcast(incidentId);
}

// The ambulance reached the receiving hospital with the patient.
async function arriveHospital(incidentId) {
    routing.forget(incidentId);
    routing.forget(`${incidentId}:ahead`);
    await db.query("UPDATE incidents SET status = 'arrived', arrived_at = ? WHERE id = ? AND status = 'picked_up'", [new Date(), incidentId]);
    return broadcast(incidentId);
}

/**
 * Every ambulance that has somewhere to be, with where it is and where it is going.
 * This is what a dispatch console or the demo simulator needs to follow the fleet.
 */
async function activeMovements() {
    const [rows] = await db.query(
        "SELECT id FROM incidents WHERE ambulance_id IS NOT NULL AND status IN ('requested', 'accepted', 'picked_up', 'unplaced')"
    );
    const out = [];
    for (const { id } of rows) {
        const job = await getSummary(id);
        if (!job || job.ambulance_lat === null) continue;
        const leg = legOf(job);
        if (leg === 'waiting') continue;
        const [lat, lng] = targetOf(job, leg);
        const from = [Number(job.ambulance_lat), Number(job.ambulance_lng)];
        const { route } = await routing.routeFor(job.id, leg, from, [lat, lng]);
        // The road may stop short of the pin; finish the last stretch to it.
        const path = [...route.geometry];
        if (routing.haversineKm(path[path.length - 1], [lat, lng]) > 0.01) path.push([lat, lng]);
        out.push({
            incident_id: job.id, ambulance_id: job.ambulance_id, source: job.ambulance_source, leg,
            from: { lat: from[0], lng: from[1] }, to: { lat, lng },
            route: path,
            // Average speed the route expects, so a simulated trip takes as long as the ETA says.
            speed_kmh: route.duration_s > 0 ? Number((route.distance_km / (route.duration_s / 3600)).toFixed(1)) : null
        });
    }
    return out;
}

// The job currently assigned to an ambulance, if any.
async function activeJobForAmbulance(ambulanceId) {
    const [[row]] = await db.query(
        "SELECT id FROM incidents WHERE ambulance_id = ? AND status IN ('requested', 'accepted', 'picked_up', 'arrived', 'unplaced') ORDER BY id DESC LIMIT 1",
        [ambulanceId]
    );
    return row ? getSummary(row.id) : null;
}

// Manual fallback for GPS drivers: "Picked up" / "Arrived at hospital".
async function driverMarkStep(user, incidentId, step) {
    const summary = await getSummary(incidentId);
    if (!summary || !user.ambulance_id || summary.ambulance_id !== user.ambulance_id) throw new DispatchError(404, 'This job is not assigned to your ambulance.');
    if (step === 'picked_up') {
        if (summary.picked_up_at) throw new DispatchError(409, 'Pick-up is already recorded.');
        if (!['requested', 'accepted', 'unplaced'].includes(summary.status)) throw new DispatchError(409, 'This job is no longer active.');
        return arrivePatient(incidentId);
    }
    if (summary.status !== 'picked_up') throw new DispatchError(409, summary.status === 'arrived' ? 'Arrival is already recorded.' : 'Record the pick-up first, and wait for a hospital to accept.');
    return arriveHospital(incidentId);
}

// ---------------- Startup ---------------- //

async function resumeOnStartup() {
    // Ambulances marked busy without an active incident were left over from a crash.
    await db.query(`
        UPDATE ambulances a SET a.status = 'available'
        WHERE a.status = 'dispatched' AND NOT EXISTS (
            SELECT 1 FROM incidents i WHERE i.ambulance_id = a.id AND i.status IN ('requested', 'accepted', 'picked_up', 'unplaced')
        )`);

    // Claim windows interrupted by the restart will never be resolved by the request
    // that opened them, so nobody should still be holding one.
    await db.query("UPDATE incident_requests SET claimed_at = NULL, claimed_by = NULL WHERE status = 'pending' AND claimed_at IS NOT NULL");
    await db.query("UPDATE ambulance_offers SET claimed_at = NULL WHERE status = 'pending' AND claimed_at IS NOT NULL");

    await sweepExpired();
    // Checked every 2 s so a request moves on at most ~2 s after its deadline.
    setInterval(sweepExpired, 2000).unref();
}

module.exports = {
    DispatchError, REQUEST_TIMEOUT_SECONDS, DISPATCH_FANOUT, CLAIM_WINDOW_MS,
    createIncident, addCandidates, accept, divert, cancel, handOver, close,
    createPublicIncident, updatePublicIncident, activePublicIncident, publicIncidentFor, cancelPublicIncident, publicRequestsNear,
    reportPosition, activeMovements, routeView, activeJobForAmbulance, driverMarkStep,
    acceptOffer, declineOffer, pendingOffers, OFFER_SECONDS,
    getDetail, getSummary, listForHospital, pendingRequestsForHospital, involves, canRead, resumeOnStartup
};
