// Road routes and ETAs.
//
// A straight line is wrong by 30-60% on Indian roads, and it says nothing about
// traffic. Routes come from, in order of preference:
//   mapbox   : driving-traffic profile, live traffic. Needs MAPBOX_TOKEN.
//   osrm     : real roads, typical speeds, no traffic. No key needed; defaults to the
//              public OSRM demo server, which is fine for development but not for
//              production -- point OSRM_URL at your own instance.
//   estimate : straight line x a road factor at an urban average speed. Used only
//              when the provider can't be reached, and labelled as an estimate.
//
// Routes are cached per incident and leg. A position report doesn't fetch a route:
// it is projected onto the cached one and the remaining time is scaled from it.
// A new route is fetched only when the destination changes, the ambulance strays
// off the route, or (with live traffic) the route is a few minutes old. The cache
// is only a cache -- losing it on restart just means one fresh fetch per trip.

const axios = require('axios');

const MAPBOX_TOKEN = process.env.MAPBOX_TOKEN || '';
const OSRM_URL = (process.env.OSRM_URL || 'https://router.project-osrm.org').replace(/\/$/, '');
const PROVIDER = MAPBOX_TOKEN ? 'mapbox'
    : (process.env.ROUTING_PROVIDER || 'osrm') === 'none' ? 'estimate' : 'osrm';

const OFF_ROUTE_KM = 0.3;              // further than this from the route: re-route
const MIN_REFETCH_MS = 20 * 1000;      // never re-fetch one trip more often than this
const TRAFFIC_REFRESH_MS = 3 * 60 * 1000;
const CACHE_TTL_MS = 2 * 60 * 60 * 1000;
const ROAD_FACTOR = 1.4;               // straight line -> road distance, for the estimate
const ESTIMATE_SPEED_KMH = 28;         // urban average for the estimate

const haversineKm = (a, b) => {
    const R = 6371, rad = (x) => (x * Math.PI) / 180;
    const dLat = rad(b[0] - a[0]), dLng = rad(b[1] - a[1]);
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
};

// Adds cumulative distances so progress along the route is cheap to compute.
function withMeasures(route) {
    const cum = [0];
    for (let i = 1; i < route.geometry.length; i++) cum.push(cum[i - 1] + haversineKm(route.geometry[i - 1], route.geometry[i]));
    return { ...route, cum, length_km: cum[cum.length - 1] || 0 };
}

async function fromMapbox(from, to) {
    const coords = `${from[1]},${from[0]};${to[1]},${to[0]}`;
    const { data } = await axios.get(`https://api.mapbox.com/directions/v5/mapbox/driving-traffic/${coords}`, {
        params: { geometries: 'geojson', overview: 'full', access_token: MAPBOX_TOKEN }, timeout: 6000
    });
    const r = data.routes?.[0];
    if (!r) throw new Error(data.code || 'no route');
    return { geometry: r.geometry.coordinates.map(([lng, lat]) => [lat, lng]), distance_km: r.distance / 1000, duration_s: r.duration, source: 'mapbox', traffic: true };
}

async function fromOsrm(from, to) {
    const coords = `${from[1]},${from[0]};${to[1]},${to[0]}`;
    const { data } = await axios.get(`${OSRM_URL}/route/v1/driving/${coords}`, {
        params: { geometries: 'geojson', overview: 'full' }, timeout: 6000
    });
    const r = data.routes?.[0];
    if (data.code !== 'Ok' || !r) throw new Error(data.code || 'no route');
    return { geometry: r.geometry.coordinates.map(([lng, lat]) => [lat, lng]), distance_km: r.distance / 1000, duration_s: r.duration, source: 'osrm', traffic: false };
}

function estimate(from, to) {
    const distance_km = haversineKm(from, to) * ROAD_FACTOR;
    return { geometry: [from, to], distance_km, duration_s: (distance_km / ESTIMATE_SPEED_KMH) * 3600, source: 'estimate', traffic: false };
}

let lastFailureLogged = 0;
async function fetchRoute(from, to) {
    try {
        if (PROVIDER === 'mapbox') return withMeasures(await fromMapbox(from, to));
        if (PROVIDER === 'osrm') return withMeasures(await fromOsrm(from, to));
    } catch (err) {
        // An ambulance is never held up by a routing outage; fall back and say so once a minute.
        if (Date.now() - lastFailureLogged > 60000) {
            console.warn(`Routing via ${PROVIDER} failed (${err.response?.status || err.message}); using a straight-line estimate.`);
            lastFailureLogged = Date.now();
        }
    }
    return withMeasures(estimate(from, to));
}

// Nearest point on the route to `pos`: how far along it is, and how far off it.
//
// Routes through one-way systems can pass the same stretch of road twice, so a
// position can sit on two parts of the route. `hintKm` -- how far along the trip was
// last time -- picks the one that continues the trip rather than jumping back.
function locate(route, pos, hintKm = null) {
    const g = route.geometry;
    if (g.length < 2) return { along_km: 0, off_km: haversineKm(pos, g[0] || pos), index: 0, point: g[0] || pos };
    // Equirectangular projection around the position: accurate enough over a few hundred metres.
    const kx = 111.32 * Math.cos((pos[0] * Math.PI) / 180), ky = 110.57;
    const candidates = [];
    for (let i = 0; i < g.length - 1; i++) {
        const ax = (g[i][1] - pos[1]) * kx, ay = (g[i][0] - pos[0]) * ky;
        const bx = (g[i + 1][1] - pos[1]) * kx, by = (g[i + 1][0] - pos[0]) * ky;
        const dx = bx - ax, dy = by - ay, len2 = dx * dx + dy * dy;
        const t = len2 ? Math.max(0, Math.min(1, -(ax * dx + ay * dy) / len2)) : 0;
        const off = Math.hypot(ax + t * dx, ay + t * dy);
        candidates.push({ off_km: off, along_km: route.cum[i] + t * (route.cum[i + 1] - route.cum[i]), index: i,
            point: [g[i][0] + t * (g[i + 1][0] - g[i][0]), g[i][1] + t * (g[i + 1][1] - g[i][1])] });
    }
    const nearest = candidates.reduce((a, b) => (b.off_km < a.off_km ? b : a));
    if (hintKm === null) return nearest;
    // Anything about as close as the nearest (GPS is good to ~20 m) is a fair match;
    // of those, take the first one not behind where the trip already got to.
    const fair = candidates.filter(c => c.off_km <= nearest.off_km + 0.02);
    const ahead = fair.filter(c => c.along_km >= hintKm - 0.05).sort((a, b) => a.along_km - b.along_km);
    return ahead[0] || nearest;
}

// How much of the trip is left from `pos`, in distance and time.
function progress(route, pos, hintKm = null) {
    const { along_km, off_km } = locate(route, pos, hintKm);
    const remaining_km = Math.max(0, route.length_km - along_km) + off_km;
    const share = route.length_km > 0 ? remaining_km / route.length_km : 0;
    return { remaining_km, along_km, eta_seconds: Math.round(route.duration_s * Math.min(1.5, share)), off_km };
}

// progress() for a trip's cached route, remembering how far along it got. Pass
// remember=false for read-only callers (a poll) so they can't move the trip.
function progressFor(incidentId, route, pos, remember = true) {
    const entry = cache.get(incidentId);
    const hint = entry && entry.route === route ? entry.lastAlong ?? null : null;
    const p = progress(route, pos, hint);
    if (remember && entry && entry.route === route) entry.lastAlong = p.along_km;
    return p;
}

const cache = new Map(); // incidentId -> { key, route, fetchedAt, version }
let version = 0;

/**
 * The route for an incident's current leg, fetching one only when needed.
 * Returns { route, changed } -- `changed` means watchers should redraw it.
 */
async function routeFor(incidentId, leg, from, to) {
    const key = `${leg}:${to[0].toFixed(5)},${to[1].toFixed(5)}`;
    const entry = cache.get(incidentId);
    const now = Date.now();

    let refetch = !entry || entry.key !== key;
    if (!refetch && now - entry.fetchedAt > MIN_REFETCH_MS) {
        const strayed = locate(entry.route, from).off_km > OFF_ROUTE_KM;
        const stale = entry.route.traffic && now - entry.fetchedAt > TRAFFIC_REFRESH_MS;
        // A failed fetch is retried too, so a short outage doesn't leave a trip on the estimate.
        const wasFallback = entry.route.source === 'estimate' && PROVIDER !== 'estimate';
        refetch = strayed || stale || wasFallback;
    }
    if (!refetch) return { route: entry.route, version: entry.version, changed: false };

    const route = await fetchRoute(from, to);
    const fresh = { key, route, fetchedAt: now, version: ++version };
    cache.set(incidentId, fresh);
    if (cache.size > 500) prune();
    return { route, version: fresh.version, changed: true };
}

// What's cached for an incident, without fetching anything.
const cachedRoute = (incidentId) => cache.get(incidentId) || null;

function forget(incidentId) {
    cache.delete(incidentId);
}

function prune() {
    const cutoff = Date.now() - CACHE_TTL_MS;
    for (const [id, e] of cache) if (e.fetchedAt < cutoff) cache.delete(id);
}

module.exports = { PROVIDER, routeFor, cachedRoute, progress, progressFor, locate, forget, haversineKm };
