// Applies doctor shifts to doctor status. Works on transitions only:
//   - a shift that started since the last tick puts an Off Duty doctor On Duty
//   - a shift that ended since the last tick takes an On Duty / On Call doctor Off Duty
//     (unless another shift is still running)
// Status changes made by hand between those moments are left alone, and doctors
// In Surgery are never switched automatically.
//
// All times are passed from Node so the comparison doesn't depend on the MySQL
// server's time zone.

const db = require('../config/db');
const { logActivity } = require('./activity');
const { broadcastDoctor } = require('../controllers/doctorController');

const TICK_MS = 30 * 1000;

let lastRun = null;

async function applyTransitions(from, to) {
    const [starting] = await db.query(`
        SELECT DISTINCT doc.id, doc.hospital_id, doc.name
        FROM doctor_shifts s
        JOIN doctors doc ON doc.id = s.doctor_id
        WHERE s.starts_at > ? AND s.starts_at <= ? AND s.ends_at > ?
          AND doc.status = 'off_duty'`, [from, to, to]);

    const [ending] = await db.query(`
        SELECT DISTINCT doc.id, doc.hospital_id, doc.name
        FROM doctor_shifts s
        JOIN doctors doc ON doc.id = s.doctor_id
        WHERE s.ends_at > ? AND s.ends_at <= ?
          AND doc.status IN ('on_duty', 'on_call')
          AND NOT EXISTS (
              SELECT 1 FROM doctor_shifts s2
              WHERE s2.doctor_id = doc.id AND s2.starts_at <= ? AND s2.ends_at > ?
          )`, [from, to, to, to]);

    for (const [doctors, status, label] of [[starting, 'on_duty', 'On Duty'], [ending, 'off_duty', 'Off Duty']]) {
        for (const doc of doctors) {
            await db.query('UPDATE doctors SET status = ?, status_updated_at = ? WHERE id = ?', [status, to, doc.id]);
            await broadcastDoctor(doc.id, doc.hospital_id);
            await logActivity({
                hospitalId: doc.hospital_id, action: 'doctor.status_changed', entityType: 'doctor', entityId: doc.id,
                summary: `${doc.name}: ${status === 'on_duty' ? 'shift started' : 'shift ended'} → ${label}`
            });
        }
    }
}

async function tick() {
    const now = new Date();
    try {
        await applyTransitions(lastRun, now);
        lastRun = now;
    } catch (err) {
        // Keep lastRun so the missed window is retried on the next tick.
        console.error('Shift scheduler error:', err.message);
    }
}

function startShiftScheduler() {
    // On startup, pick up transitions from the last few minutes (covers a quick restart).
    lastRun = new Date(Date.now() - 5 * 60 * 1000);
    tick();
    setInterval(tick, TICK_MS).unref();
}

module.exports = { startShiftScheduler, applyTransitions };
