// Identity for the public app.
//
// There is no sign-in. Nothing may stand between a caller and an ambulance, so the
// app asks for no password, no code and no waiting: it generates a random id on
// first open and that id is the account.
//
// Identity is deliberately NOT the phone number. If typing a number granted a
// session, anyone could type a stranger's number and read their booking history and
// the live location of their patient. The number is contact detail that the crew
// rings, stored on the booking, never a credential.
//
// Public tokens are signed with a secret derived from JWT_SECRET, so a citizen token
// can never verify as a hospital token even by accident.

const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const db = require('../config/db');

const TOKEN_DAYS = 365; // a citizen must never be logged out before an emergency

const publicSecret = () =>
    crypto.createHmac('sha256', process.env.JWT_SECRET || '').update('bma-public-app').digest('hex');

class PublicAuthError extends Error {
    constructor(status, message) {
        super(message);
        this.status = status;
    }
}

// Indian mobile numbers, with or without +91. Stored as +91 plus ten digits.
// Returns null for anything unusable rather than throwing: a malformed number must
// never stop an ambulance, it just means the crew has no one to ring.
function normalisePhone(raw) {
    const digits = String(raw || '').replace(/\D/g, '');
    const local = digits.length > 10 ? digits.slice(-10) : digits;
    return /^[6-9]\d{9}$/.test(local) ? `+91${local}` : null;
}

const toProfile = (u) => ({
    id: u.id,
    phone: u.phone,
    phone_verified: Boolean(u.phone_verified),
    name: u.name,
    blood_group: u.blood_group,
    allergies: u.allergies,
    conditions: u.conditions
});

/**
 * Hands back a token for this device, creating the account on first contact.
 * Called once when the app opens; it asks the caller for nothing.
 */
async function startSession(deviceId, ip) {
    const id = String(deviceId || '').trim();
    if (!/^[A-Za-z0-9_-]{16,64}$/.test(id)) throw new PublicAuthError(400, 'Invalid device id.');

    await db.query(
        `INSERT INTO public_users (device_id, last_seen_at, last_ip) VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE last_seen_at = VALUES(last_seen_at), last_ip = VALUES(last_ip)`,
        [id, new Date(), ip || null]
    );
    const [[user]] = await db.query('SELECT * FROM public_users WHERE device_id = ?', [id]);
    if (user.is_blocked) throw new PublicAuthError(403, 'This device is blocked. Call 108 for an ambulance.');

    return {
        token: jwt.sign({ pid: user.id, aud: 'public' }, publicSecret(), { expiresIn: `${TOKEN_DAYS}d` }),
        user: toProfile(user)
    };
}

// Express middleware for the /api/public routes that act on an account.
async function verifyPublicToken(req, res, next) {
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Your session could not be read. Reload the app.' });
    try {
        const decoded = jwt.verify(token, publicSecret(), { audience: 'public' });
        const [[user]] = await db.query('SELECT * FROM public_users WHERE id = ?', [decoded.pid]);
        if (!user) return res.status(401).json({ error: 'Your session has expired. Reload the app.' });
        if (user.is_blocked) return res.status(403).json({ error: 'This device is blocked. Call 108 for an ambulance.' });
        req.publicUser = user;
        next();
    } catch {
        return res.status(401).json({ error: 'Your session has expired. Reload the app.' });
    }
}

async function updateProfile(userId, fields) {
    const allowed = ['name', 'blood_group', 'allergies', 'conditions'];
    const sets = allowed.filter(f => fields[f] !== undefined);
    if (sets.length) {
        await db.query(`UPDATE public_users SET ${sets.map(f => `${f} = ?`).join(', ')} WHERE id = ?`,
            [...sets.map(f => fields[f] || null), userId]);
    }
    const [[user]] = await db.query('SELECT * FROM public_users WHERE id = ?', [userId]);
    return toProfile(user);
}

// Remembers the number the caller last gave, so the field is pre-filled next time.
async function rememberPhone(userId, phone) {
    if (phone) await db.query('UPDATE public_users SET phone = ? WHERE id = ?', [phone, userId]);
}

module.exports = { PublicAuthError, startSession, verifyPublicToken, updateProfile, normalisePhone, rememberPhone, toProfile };
