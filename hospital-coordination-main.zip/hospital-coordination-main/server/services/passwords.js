const crypto = require('crypto');

// Readable temporary password for new or reset accounts (no 0/O, 1/l/I look-alikes).
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';

function generateTemporaryPassword(length = 10) {
    const bytes = crypto.randomBytes(length);
    return Array.from(bytes, b => ALPHABET[b % ALPHABET.length]).join('');
}

module.exports = { generateTemporaryPassword };
