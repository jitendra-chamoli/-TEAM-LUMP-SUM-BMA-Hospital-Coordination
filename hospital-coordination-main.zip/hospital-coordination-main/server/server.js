const express = require('express');
const http = require('http');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const dotenv = require('dotenv');
const db = require('./config/db');
const { runMigrations } = require('./db/migrate');
const { initRealtime } = require('./realtime');
const { startShiftScheduler } = require('./services/shiftScheduler');

const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./config/swagger');

// Route Imports
const authRoutes = require('./routes/authRoutes');
const staffRoutes = require('./routes/staffRoutes');
const resourceRoutes = require('./routes/resourceRoutes');
const doctorRoutes = require('./routes/doctorRoutes');
const incidentRoutes = require('./routes/incidentRoutes');
const activityRoutes = require('./routes/activityRoutes');
const hospitalRoutes = require('./routes/hospitalRoutes');
const dispatchRoutes = require('./routes/dispatchRoutes');
const fleetRoutes = require('./routes/fleetRoutes');
const driverRoutes = require('./routes/driverRoutes');
const publicRoutes = require('./routes/publicRoutes');
const telemetryRoutes = require('./routes/telemetryRoutes');
const dispatch = require('./services/dispatch');
// Load environment variables
dotenv.config();

const app = express();
const server = http.createServer(app);

const CLIENT_URL = process.env.CLIENT_URL || 'http://localhost:3000';
// The citizen app is a separate front-end on its own origin.
const USER_APP_URL = process.env.USER_APP_URL || 'http://localhost:3001';
const ALLOWED_ORIGINS = [...new Set([CLIENT_URL, USER_APP_URL])];

// 1. Middleware
app.use(helmet());
app.use(cors({ origin: ALLOWED_ORIGINS })); // The hospital portal and the citizen app
app.use(express.json()); // Parses incoming JSON requests

// Generous general limit for all API traffic
const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 300,
    standardHeaders: true,
    legacyHeaders: false
});
// Vehicle trackers and the demo simulator report every second or so; they carry
// their own token and sit outside the per-IP limit meant for people.
app.use('/api/telemetry', telemetryRoutes);

app.use('/api', apiLimiter);

// Tighter limit on auth endpoints to slow down credential brute-forcing
const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 15,
    standardHeaders: true,
    legacyHeaders: false,
    message: { message: "Too many attempts. Please try again later." }
});
app.use('/api/auth', authLimiter);

// 2. Socket.io Setup — authenticated connections, one room per hospital (see realtime.js)
initRealtime(server, CLIENT_URL);

// 3. API Routes
app.use('/api/auth', authRoutes);
app.use('/api/staff', staffRoutes);
app.use('/api/resources', resourceRoutes);
app.use('/api/doctors', doctorRoutes);
app.use('/api/incidents', incidentRoutes);
app.use('/api/activity', activityRoutes);
app.use('/api/hospital', hospitalRoutes);
app.use('/api/dispatch', dispatchRoutes);
app.use('/api/fleet', fleetRoutes);
app.use('/api/driver', driverRoutes);
app.use('/api/public', publicRoutes);

// Health Check Route
app.get('/', (req, res) => {
    res.send('Hospital Coordination API is running...');
});

app.use(
  '/api-docs',
  swaggerUi.serve,
  swaggerUi.setup(swaggerSpec)
);

// 4. Start the Server
// Creates/updates the schema (db/migrations) and verifies the pool before accepting traffic.
const PORT = process.env.PORT || 5000;

async function start() {
    try {
        await runMigrations();
        const [rows] = await db.query('SELECT 1 + 1 AS result');
        console.log('✅ MySQL connected. Test Result:', rows[0].result);

        // Free ambulances stranded by a crash and resume pending hospital requests.
        await dispatch.resumeOnStartup();
    } catch (err) {
        console.error('❌ Database setup failed:', err.message);
        process.exit(1); // Stop the server if DB is not reachable
    }

    server.listen(PORT, () => {
        console.log(`🚀 Server running on http://localhost:${PORT}`);
    });

    startShiftScheduler();
}

start();
