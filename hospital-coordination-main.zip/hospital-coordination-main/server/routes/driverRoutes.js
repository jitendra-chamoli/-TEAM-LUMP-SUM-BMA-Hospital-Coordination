const express = require('express');
const router = express.Router();
const c = require('../controllers/driverController');
const { verifyToken } = require('../middleware/authMiddleware');
const requireRole = require('../middleware/requireRole');
const validate = require('../middleware/validate');
const schemas = require('../middleware/schemas');

// The driver's phone app
router.use(verifyToken, requireRole('driver'));

router.get('/me', c.getMe);
router.post('/shift', validate(schemas.driverShift), c.setShift);
router.post('/location', validate(schemas.driverLocation), c.updateLocation);
router.post('/offers/:id/accept', c.acceptOffer);
router.post('/offers/:id/decline', c.declineOffer);
router.get('/jobs/:id/route', c.jobRoute);
router.post('/jobs/:id/picked-up', c.markStep('picked_up'));
router.post('/jobs/:id/arrived', c.markStep('arrived'));

module.exports = router;
