const express = require('express');
const router = express.Router();
const doctorController = require('../controllers/doctorController');
const { verifyToken } = require('../middleware/authMiddleware');
const requireRole = require('../middleware/requireRole');
const validate = require('../middleware/validate');
const schemas = require('../middleware/schemas');

const admin = requireRole('admin');

// Roster (admins see every department; staff and doctors see their own)
router.get('/', verifyToken, doctorController.getDoctors);
router.post('/add', verifyToken, admin, validate(schemas.addDoctor), doctorController.addDoctor);
router.patch('/:id', verifyToken, admin, validate(schemas.updateDoctor), doctorController.updateDoctor);
router.delete('/:id', verifyToken, admin, doctorController.deleteDoctor);

// Status: admin any doctor, staff their department, doctors themselves (checked in the controller)
router.post('/:id/status', verifyToken, validate(schemas.doctorStatus), doctorController.setStatus);

// Doctor's own sign-in
router.post('/:id/login', verifyToken, admin, validate(schemas.createDoctorLogin), doctorController.createLogin);

// Shifts: admin, or staff of the doctor's department (checked in the controller)
router.get('/:id/shifts', verifyToken, requireRole('admin', 'staff'), doctorController.getShifts);
router.post('/:id/shifts', verifyToken, requireRole('admin', 'staff'), validate(schemas.addShift), doctorController.addShift);
router.delete('/shifts/:shiftId', verifyToken, requireRole('admin', 'staff'), doctorController.deleteShift);

module.exports = router;
