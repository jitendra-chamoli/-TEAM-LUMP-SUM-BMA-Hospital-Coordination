const express = require('express');
const router = express.Router();
const { addStaff, getStaff, updateStaff, resetStaffPassword } = require('../controllers/staffController');
const { verifyToken } = require('../middleware/authMiddleware');
const requireRole = require('../middleware/requireRole');
const validate = require('../middleware/validate');
const schemas = require('../middleware/schemas');

router.use(verifyToken, requireRole('admin'));

router.get('/', getStaff);
router.post('/add', validate(schemas.addStaff), addStaff);
router.patch('/:id', validate(schemas.updateStaff), updateStaff);
router.post('/:id/reset-password', resetStaffPassword);

module.exports = router;
