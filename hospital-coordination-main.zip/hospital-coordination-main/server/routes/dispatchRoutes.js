const express = require('express');
const router = express.Router();
const { getConfig } = require('../controllers/incidentController');
const { verifyToken } = require('../middleware/authMiddleware');

// Complaint list, divert reasons and timeout used by the dispatch screens
router.get('/config', verifyToken, getConfig);

module.exports = router;
