const express = require('express');
const router = express.Router();
const c = require('../controllers/fleetController');
const { verifyToken } = require('../middleware/authMiddleware');
const requireRole = require('../middleware/requireRole');
const validate = require('../middleware/validate');
const schemas = require('../middleware/schemas');

// Admin: the hospital's own ambulances and drivers
router.use(verifyToken, requireRole('admin'));

router.get('/', c.getFleet);
router.post('/ambulances', validate(schemas.addAmbulance), c.addAmbulance);
router.patch('/ambulances/:id', validate(schemas.updateAmbulance), c.updateAmbulance);
router.post('/drivers', validate(schemas.addDriver), c.addDriver);
router.patch('/drivers/:id', validate(schemas.updateDriver), c.updateDriver);
router.post('/drivers/:id/reset-password', c.resetDriverPassword);

module.exports = router;
