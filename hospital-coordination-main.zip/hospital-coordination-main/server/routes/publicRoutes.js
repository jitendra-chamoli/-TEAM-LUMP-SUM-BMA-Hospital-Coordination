const express = require('express');
const rateLimit = require('express-rate-limit');
const router = express.Router();
const c = require('../controllers/publicController');
const { verifyPublicToken } = require('../services/publicAuth');
const validate = require('../middleware/validate');
const schemas = require('../middleware/schemas');

// Sessions are unauthenticated and free to create, so they get their own ceiling.
// Generous: a real caller may reload the app several times in a panic.
const sessionLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, limit: 40, standardHeaders: true, legacyHeaders: false,
    message: { error: 'Too many attempts from this device. Please call 108.' }
});

router.get('/config', c.getConfig);
router.post('/session', sessionLimiter, validate(schemas.publicSession), c.startSession);

// Everything below acts on one device's account.
router.use(verifyPublicToken);
router.get('/me', c.getMe);
router.patch('/me', validate(schemas.publicProfile), c.updateProfile);
router.post('/requests', validate(schemas.publicRequest), c.createRequest);
router.get('/requests', c.history);
router.get('/requests/:id', c.getRequest);
router.get('/requests/:id/route', c.getRoute);
// Details added after the ambulance is already on its way
router.patch('/requests/:id', validate(schemas.publicRequestUpdate), c.updateRequest);
router.post('/requests/:id/cancel', validate(schemas.publicCancel), c.cancelRequest);

// Anything else under /api/public is genuinely absent, not a permissions problem.
router.use((req, res) => res.status(404).json({ error: 'Not found' }));

module.exports = router;
