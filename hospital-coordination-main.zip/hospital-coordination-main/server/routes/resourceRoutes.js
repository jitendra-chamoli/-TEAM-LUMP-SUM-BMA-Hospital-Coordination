const express = require('express');
const router = express.Router();
const { getResources, updateResource, initResource } = require('../controllers/resourceController');
const { verifyToken } = require('../middleware/authMiddleware');
const requireRole = require('../middleware/requireRole');
const validate = require('../middleware/validate');
const schemas = require('../middleware/schemas');

// GET /api/resources - Fetch all resources for admin or the user's department otherwise
router.get('/', verifyToken, getResources);

// Doctors can view but not change resource counts
router.patch('/update', verifyToken, requireRole('admin', 'staff'), validate(schemas.updateResource), updateResource);
router.post('/init', verifyToken, requireRole('admin', 'staff'), validate(schemas.initResource), initResource);

module.exports = router;
