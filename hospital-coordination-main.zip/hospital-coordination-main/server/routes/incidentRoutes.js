const express = require('express');
const router = express.Router();
const c = require('../controllers/incidentController');
const pub = require('../controllers/publicController');
const { verifyToken } = require('../middleware/authMiddleware');
const requireRole = require('../middleware/requireRole');
const validate = require('../middleware/validate');
const schemas = require('../middleware/schemas');

const dispatcher = requireRole('admin', 'staff');
const hospitalUser = requireRole('admin', 'staff', 'doctor');

// Incidents received by or requested from the user's hospital
router.get('/', verifyToken, hospitalUser, c.getIncidents);
router.get('/requests/pending', verifyToken, dispatcher, c.getPendingRequests);
router.get('/public/nearby', verifyToken, dispatcher, pub.nearbyPublicRequests);
router.get('/:id', verifyToken, hospitalUser, c.getIncident);
router.get('/:id/route', verifyToken, hospitalUser, c.getRoute);

// Create a dispatch: reserves the ambulance and asks every chosen hospital at once
router.post('/', verifyToken, dispatcher, validate(schemas.createIncident), c.createIncident);

// Receiving hospital
router.post('/:id/accept', verifyToken, dispatcher, c.accept);
router.post('/:id/divert', verifyToken, dispatcher, validate(schemas.divertIncident), c.divert);
router.post('/:id/handover', verifyToken, dispatcher, c.handOver);

// Either hospital
router.post('/:id/cancel', verifyToken, dispatcher, validate(schemas.cancelIncident), c.cancel);
router.post('/:id/close', verifyToken, dispatcher, c.close);
router.post('/:id/police-informed', verifyToken, dispatcher, pub.markPoliceInformed);
router.post('/:id/identify', verifyToken, dispatcher, validate(schemas.identifyPatient), pub.identifyPatient);

// Requesting hospital: try more hospitals after nobody accepted
router.post('/:id/candidates', verifyToken, dispatcher, validate(schemas.addCandidates), c.addCandidates);

module.exports = router;
