const express = require('express');
const router = express.Router();
const { getHospital, updateHospital, setSchemes, setTariffs } = require('../controllers/hospitalController');
const { verifyToken } = require('../middleware/authMiddleware');
const requireRole = require('../middleware/requireRole');
const validate = require('../middleware/validate');
const schemas = require('../middleware/schemas');

router.get('/', verifyToken, getHospital);
router.patch('/', verifyToken, requireRole('admin'), validate(schemas.updateHospital), updateHospital);
router.put('/schemes', verifyToken, requireRole('admin'), validate(schemas.hospitalSchemes), setSchemes);
router.put('/tariffs', verifyToken, requireRole('admin'), validate(schemas.hospitalTariffs), setTariffs);

module.exports = router;
