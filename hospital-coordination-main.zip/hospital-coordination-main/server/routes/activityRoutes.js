const express = require('express');
const router = express.Router();
const { getActivity, getActivityUsers } = require('../controllers/activityController');
const { verifyToken } = require('../middleware/authMiddleware');
const requireRole = require('../middleware/requireRole');

router.get('/', verifyToken, requireRole('admin'), getActivity);
router.get('/users', verifyToken, requireRole('admin'), getActivityUsers);

module.exports = router;
