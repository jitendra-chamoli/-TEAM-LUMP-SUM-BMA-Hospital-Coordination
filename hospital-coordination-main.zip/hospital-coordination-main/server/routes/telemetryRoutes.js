// Machine-to-machine position feed for ambulances that have no driver phone: a
// vehicle tracker, or the demo simulator in simulator/. Both report positions the
// same way a driver's phone does; the server can't tell them apart and doesn't try.
//
// Off unless TELEMETRY_TOKEN is set. Callers send it as a bearer token.

const express = require('express');
const { timingSafeEqual } = require('crypto');
const { z } = require('zod');
const db = require('../config/db');
const dispatch = require('../services/dispatch');
const { emitToHospitals } = require('../realtime');

const router = express.Router();
const TOKEN = process.env.TELEMETRY_TOKEN || '';

const sameSecret = (given) => {
    const a = Buffer.from(given || ''), b = Buffer.from(TOKEN);
    return a.length === b.length && timingSafeEqual(a, b);
};

router.use((req, res, next) => {
    // Disabled: behave as if the route doesn't exist.
    if (!TOKEN) return res.status(404).json({ error: 'Not found' });
    const given = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (!sameSecret(given)) return res.status(401).json({ error: 'Invalid telemetry token' });
    next();
});

// Where every busy ambulance is and where it should be heading.
router.get('/jobs', async (req, res) => {
    try {
        res.json(await dispatch.activeMovements());
    } catch (err) {
        console.error('Telemetry jobs:', err);
        res.status(500).json({ error: 'Could not load jobs' });
    }
});

// Job offers for the demo fleet. Demo ambulances have no driver, so whatever plays
// their trackers (the simulator) also answers their offers.
router.get('/offers', async (req, res) => {
    try {
        res.json(await dispatch.pendingOffers({ demo: true }));
    } catch (err) {
        console.error('Telemetry offers:', err);
        res.status(500).json({ error: 'Could not load offers' });
    }
});

router.post('/offers/:id/accept', async (req, res) => {
    try {
        await dispatch.acceptOffer(Number(req.params.id), { demo: true });
        res.json({ ok: true });
    } catch (err) {
        if (err instanceof dispatch.DispatchError) return res.status(err.status).json({ error: err.message });
        console.error('Telemetry accept:', err);
        res.status(500).json({ error: 'Could not accept the offer' });
    }
});

const positionsSchema = z.object({
    positions: z.array(z.object({
        ambulance_id: z.number().int().positive(),
        lat: z.number().min(-90).max(90),
        lng: z.number().min(-180).max(180)
    })).max(500)
});

router.post('/positions', async (req, res) => {
    const parsed = positionsSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Invalid positions' });

    try {
        const now = new Date();
        let applied = 0;
        for (const { ambulance_id, lat, lng } of parsed.data.positions) {
            // An ambulance with a driver on shift is tracked by the driver's phone. A
            // second source would make it jump between two positions.
            const [r] = await db.query(
                "UPDATE ambulances SET latitude = ?, longitude = ?, location_updated_at = ? WHERE id = ? AND location_source <> 'gps'",
                [lat, lng, now, ambulance_id]
            );
            if (!r.affectedRows) continue;
            applied++;

            const [[a]] = await db.query('SELECT hospital_id FROM ambulances WHERE id = ?', [ambulance_id]);
            if (a?.hospital_id) emitToHospitals(a.hospital_id, 'fleet_location', { ambulance_id, lat, lng, at: now.toISOString() });
            await dispatch.reportPosition(ambulance_id, lat, lng);
        }
        res.json({ applied, ignored: parsed.data.positions.length - applied });
    } catch (err) {
        console.error('Telemetry positions:', err);
        res.status(500).json({ error: 'Could not save positions' });
    }
});

module.exports = router;
