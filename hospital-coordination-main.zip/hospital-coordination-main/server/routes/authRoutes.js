const express = require('express');
const router = express.Router();
const { register, login, changePassword } = require('../controllers/authController');
const { verifyTokenAllowPasswordChange } = require('../middleware/authMiddleware');
const validate = require('../middleware/validate');
const schemas = require('../middleware/schemas');

router.post('/register', validate(schemas.register), register);
router.post('/login', validate(schemas.login), login);
router.post('/change-password', verifyTokenAllowPasswordChange, validate(schemas.changePassword), changePassword);

module.exports = router;
