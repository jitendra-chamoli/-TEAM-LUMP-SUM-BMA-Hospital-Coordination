-- Real drivers: hospital-owned ambulances, driver accounts, shifts and live GPS.
-- The demo fleet imported in 003 (hospital_id NULL, location_source 'demo') keeps working.

ALTER TABLE ambulances
    MODIFY driver_name VARCHAR(100) NULL,                -- filled from the driver on shift for hospital ambulances
    MODIFY contact     VARCHAR(20)  NULL,
    ADD COLUMN vehicle_number      VARCHAR(20) NULL AFTER hospital_id,
    ADD COLUMN type                ENUM('basic', 'advanced', 'icu') NOT NULL DEFAULT 'basic' AFTER vehicle_number,
    ADD COLUMN current_driver_id   INT NULL AFTER contact,
    ADD COLUMN location_source     ENUM('demo', 'gps') NOT NULL DEFAULT 'demo' AFTER longitude,
    ADD COLUMN location_updated_at DATETIME NULL AFTER location_source,
    ADD COLUMN location_accuracy_m SMALLINT UNSIGNED NULL AFTER location_updated_at,
    ADD COLUMN is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    ADD CONSTRAINT uq_ambulances_vehicle UNIQUE (vehicle_number),
    ADD INDEX idx_ambulances_hospital (hospital_id);

ALTER TABLE users
    MODIFY role ENUM('admin', 'staff', 'doctor', 'driver') NOT NULL,
    ADD COLUMN phone        VARCHAR(20) NULL AFTER email,
    ADD COLUMN ambulance_id INT NULL AFTER doctor_id,     -- the ambulance a driver is assigned to
    ADD CONSTRAINT fk_users_ambulance FOREIGN KEY (ambulance_id) REFERENCES ambulances(id) ON DELETE SET NULL;

ALTER TABLE ambulances
    ADD CONSTRAINT fk_ambulances_driver FOREIGN KEY (current_driver_id) REFERENCES users(id) ON DELETE SET NULL;
