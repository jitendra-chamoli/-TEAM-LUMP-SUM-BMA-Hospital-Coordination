-- Phase 1: nothing stands between a caller and an ambulance.
--
-- The one-time password was a barrier in front of a 999-equivalent: someone standing
-- over an accident victim had to wait for an SMS before help could be sent. Dispatch
-- now happens on the first tap, and the caller's number is simply a field on the
-- booking so the crew can ring them.
--
-- Identity moves from the phone number to the device. A phone number alone must never
-- grant a session: anyone could type a stranger's number and read their booking history
-- and the live location of their patient. The app generates a random id on first open
-- and keeps it locally, so a session is bound to the handset instead.

ALTER TABLE public_users
    ADD COLUMN device_id VARCHAR(64) NULL AFTER id,
    -- Several devices can legitimately share a number: a family, a shared phone at a
    -- shop. The number is contact detail, not an identity, so the unique key goes.
    MODIFY phone VARCHAR(20) NULL,
    ADD COLUMN phone_verified BOOLEAN NOT NULL DEFAULT FALSE AFTER phone,
    ADD COLUMN last_ip VARCHAR(45) NULL AFTER last_seen_at,
    ADD COLUMN request_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER last_ip;

-- Existing rows came from the OTP flow, so their numbers really were verified.
UPDATE public_users SET phone_verified = TRUE WHERE phone IS NOT NULL;

-- Give any existing row a device id so the unique index below can be added.
UPDATE public_users SET device_id = CONCAT('legacy-', id) WHERE device_id IS NULL;

ALTER TABLE public_users
    MODIFY device_id VARCHAR(64) NOT NULL,
    DROP INDEX phone,
    ADD CONSTRAINT uq_public_device UNIQUE (device_id),
    ADD INDEX idx_public_phone (phone);

-- No SMS gateway, so no codes to store. Verification can come back later as an
-- optional step after dispatch, never before it.
DROP TABLE IF EXISTS otp_codes;
