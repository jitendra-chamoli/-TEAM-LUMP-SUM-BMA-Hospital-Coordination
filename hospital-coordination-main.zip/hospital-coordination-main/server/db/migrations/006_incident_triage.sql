-- Triage details captured at dispatch time.
ALTER TABLE incidents
    ADD COLUMN severity ENUM('critical', 'serious', 'stable') NULL AFTER status,
    ADD COLUMN needs_icu BOOLEAN NOT NULL DEFAULT FALSE AFTER severity;
