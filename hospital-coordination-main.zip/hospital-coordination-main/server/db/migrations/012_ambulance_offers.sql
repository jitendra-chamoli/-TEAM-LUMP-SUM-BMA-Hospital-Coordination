-- Drivers accept jobs instead of being assigned them.
--
-- The nearest ambulance used to be reserved the moment a request was made, and its
-- driver simply found a job on their screen. Now the nearest few drivers on shift
-- are offered the job at once, with a short countdown; the first to accept gets it
-- (the nearer one if two accept together). If nobody accepts, the next few nearest
-- are asked. Finding a driver runs alongside finding a hospital; neither waits for
-- the other.

CREATE TABLE IF NOT EXISTS ambulance_offers (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    incident_id  INT NOT NULL,
    ambulance_id INT NOT NULL,
    -- NULL for a demo ambulance: it has no driver, and the demo simulator answers for it.
    driver_id    INT NULL,
    round        TINYINT UNSIGNED NOT NULL,
    -- Nearest first within a round. Decides a tie between two drivers accepting together.
    rank_order   TINYINT UNSIGNED NOT NULL,
    distance_km  DECIMAL(7, 2) NOT NULL,
    status       ENUM('pending', 'accepted', 'declined', 'expired', 'cancelled') NOT NULL DEFAULT 'pending',
    sent_at      DATETIME NOT NULL,
    expires_at   DATETIME NOT NULL,
    claimed_at   DATETIME(3) NULL,
    responded_at DATETIME NULL,
    CONSTRAINT fk_offers_incident  FOREIGN KEY (incident_id)  REFERENCES incidents(id) ON DELETE CASCADE,
    CONSTRAINT fk_offers_ambulance FOREIGN KEY (ambulance_id) REFERENCES ambulances(id) ON DELETE CASCADE,
    CONSTRAINT fk_offers_driver    FOREIGN KEY (driver_id)    REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_offers_incident (incident_id, status, rank_order),
    INDEX idx_offers_ambulance (ambulance_id, status),
    INDEX idx_offers_driver (driver_id, status),
    INDEX idx_offers_expiry (status, expires_at)
);

-- searching: drivers are being asked · assigned: one accepted · failed: nobody did
ALTER TABLE incidents
    ADD COLUMN ambulance_search ENUM('searching', 'assigned', 'failed') NULL AFTER ambulance_id;

UPDATE incidents SET ambulance_search = 'assigned' WHERE ambulance_id IS NOT NULL;
