-- Parallel dispatch: every candidate hospital is asked at once rather than in turn.
--
-- Asking hospitals one at a time meant a patient could wait 5 x 60s before anyone
-- even saw the request. Now all of them see it immediately and the first to accept
-- wins. Two hospitals can therefore accept within milliseconds of each other, so a
-- claim is recorded first and resolved a moment later in favour of the better-ranked
-- hospital -- "first to answer" should not beat "best for this patient" when the two
-- answers arrive together.

ALTER TABLE incident_requests
    ADD COLUMN claimed_at DATETIME(3) NULL AFTER responded_at,
    ADD COLUMN claimed_by INT NULL AFTER claimed_at,
    ADD CONSTRAINT fk_requests_claimer FOREIGN KEY (claimed_by) REFERENCES users(id) ON DELETE SET NULL,
    -- Resolving a claim window reads every open request for one incident by rank.
    ADD INDEX idx_requests_race (incident_id, status, rank_order);

-- Anything left 'queued' predates parallel dispatch. Live incidents must not keep a
-- hospital that will now never be asked; settled ones just get an accurate record.
UPDATE incident_requests r
    JOIN incidents i ON i.id = r.incident_id
    SET r.status = 'cancelled', r.reason = 'Superseded by parallel dispatch'
    WHERE r.status = 'queued';
