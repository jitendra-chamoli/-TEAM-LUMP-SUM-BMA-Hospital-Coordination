-- Dispatch workflow: the receiving hospital accepts or diverts each request,
-- beds are held on acceptance, and every stage of the journey is timestamped.

-- Departments needed for complaint-based routing
INSERT IGNORE INTO departments (name) VALUES ('Obstetrics & Gynaecology'), ('Paediatrics');

-- New lifecycle. Old 'dispatched' / 'en_route' rows become 'accepted'.
ALTER TABLE incidents
    MODIFY status ENUM('dispatched', 'en_route', 'requested', 'accepted', 'picked_up', 'arrived', 'handed_over', 'closed', 'cancelled', 'unplaced')
        NOT NULL DEFAULT 'requested';

UPDATE incidents SET status = 'accepted' WHERE status IN ('dispatched', 'en_route');

ALTER TABLE incidents
    MODIFY status ENUM('requested', 'accepted', 'picked_up', 'arrived', 'handed_over', 'closed', 'cancelled', 'unplaced')
        NOT NULL DEFAULT 'requested',
    -- Patient & caller
    ADD COLUMN patient_name   VARCHAR(100) NULL AFTER city,
    ADD COLUMN patient_age    TINYINT UNSIGNED NULL AFTER patient_name,
    ADD COLUMN patient_sex    ENUM('female', 'male', 'other') NULL AFTER patient_age,
    ADD COLUMN caller_phone   VARCHAR(20) NULL AFTER patient_sex,
    ADD COLUMN complaint      VARCHAR(30) NULL AFTER caller_phone,
    ADD COLUMN notes          VARCHAR(500) NULL AFTER complaint,
    ADD COLUMN pickup_address VARCHAR(500) NULL AFTER notes,
    -- Timeline (dispatched_at = requested, arrived_at = arrived at hospital)
    ADD COLUMN accepted_at    DATETIME NULL AFTER dispatched_at,
    ADD COLUMN picked_up_at   DATETIME NULL AFTER accepted_at,
    ADD COLUMN handed_over_at DATETIME NULL AFTER arrived_at,
    ADD COLUMN closed_at      DATETIME NULL AFTER handed_over_at,
    ADD COLUMN cancelled_at   DATETIME NULL AFTER closed_at,
    ADD COLUMN cancel_reason  VARCHAR(255) NULL AFTER cancelled_at,
    ADD COLUMN cancelled_by   INT NULL AFTER cancel_reason,
    ADD CONSTRAINT fk_incidents_cancelled_by FOREIGN KEY (cancelled_by) REFERENCES users(id) ON DELETE SET NULL,
    ADD INDEX idx_incidents_status (status);

-- One row per hospital asked, in ranked order. Only one is 'pending' at a time;
-- the rest wait as 'queued' and are tried if the current one diverts or times out.
CREATE TABLE IF NOT EXISTS incident_requests (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    incident_id   INT NOT NULL,
    hospital_id   INT NOT NULL,
    rank_order    TINYINT UNSIGNED NOT NULL,
    status        ENUM('queued', 'pending', 'accepted', 'diverted', 'expired', 'cancelled') NOT NULL DEFAULT 'queued',
    reason        VARCHAR(255) NULL,
    responded_by  INT NULL,
    sent_at       DATETIME NULL,
    expires_at    DATETIME NULL,
    responded_at  DATETIME NULL,
    CONSTRAINT fk_requests_incident  FOREIGN KEY (incident_id)  REFERENCES incidents(id) ON DELETE CASCADE,
    CONSTRAINT fk_requests_hospital  FOREIGN KEY (hospital_id)  REFERENCES hospitals(id) ON DELETE CASCADE,
    CONSTRAINT fk_requests_responder FOREIGN KEY (responded_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_requests_pending (status, expires_at),
    INDEX idx_requests_hospital (hospital_id, status)
);

-- Beds (and ICU beds) reserved when a hospital accepts. Released if the incident
-- is cancelled; marked used once the patient is handed over.
CREATE TABLE IF NOT EXISTS bed_holds (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    incident_id  INT NOT NULL,
    resource_id  INT NOT NULL,
    status       ENUM('held', 'released', 'used') NOT NULL DEFAULT 'held',
    created_at   DATETIME NOT NULL,
    updated_at   DATETIME NULL,
    CONSTRAINT fk_holds_incident FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE CASCADE,
    CONSTRAINT fk_holds_resource FOREIGN KEY (resource_id) REFERENCES hospital_resources(id) ON DELETE CASCADE,
    INDEX idx_holds_incident (incident_id)
);
