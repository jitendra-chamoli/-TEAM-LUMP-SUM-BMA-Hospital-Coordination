-- Staff management & doctor roster improvements:
-- doctor logins, forced password change, richer doctor status, shifts,
-- who-requested-what on incidents, and an activity log.

-- Users: doctor accounts (linked to their roster entry) and first-login password change
ALTER TABLE users
    MODIFY role ENUM('admin', 'staff', 'doctor') NOT NULL,
    ADD COLUMN doctor_id INT NULL UNIQUE AFTER department_id,
    ADD COLUMN must_change_password BOOLEAN NOT NULL DEFAULT FALSE AFTER password_hash,
    ADD CONSTRAINT fk_users_doctor FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE;

-- Doctors: four-state status instead of on/off, plus contact details
ALTER TABLE doctors
    ADD COLUMN status ENUM('on_duty', 'on_call', 'in_surgery', 'off_duty') NOT NULL DEFAULT 'off_duty' AFTER name,
    ADD COLUMN specialization VARCHAR(100) NULL AFTER status,
    ADD COLUMN phone VARCHAR(20) NULL AFTER specialization,
    ADD COLUMN status_updated_at TIMESTAMP NULL AFTER phone;

UPDATE doctors SET status = IF(is_available, 'on_duty', 'off_duty');

ALTER TABLE doctors DROP COLUMN is_available;

-- Planned shifts. A shift starting puts an off-duty doctor on duty; a shift ending
-- takes them off duty. Manual status changes in between always win.
CREATE TABLE IF NOT EXISTS doctor_shifts (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    doctor_id   INT NOT NULL,
    starts_at   DATETIME NOT NULL,
    ends_at     DATETIME NOT NULL,
    created_by  INT NULL,
    CONSTRAINT chk_shift_order CHECK (ends_at > starts_at),
    CONSTRAINT fk_shifts_doctor  FOREIGN KEY (doctor_id)  REFERENCES doctors(id) ON DELETE CASCADE,
    CONSTRAINT fk_shifts_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_shifts_doctor_time (doctor_id, starts_at),
    INDEX idx_shifts_starts (starts_at),
    INDEX idx_shifts_ends (ends_at)
);

-- Incidents: who asked for the dispatch, and which doctor is receiving the patient
ALTER TABLE incidents
    ADD COLUMN requested_by_user_id INT NULL AFTER ambulance_id,
    ADD COLUMN requested_by_hospital_id INT NULL AFTER requested_by_user_id,
    ADD COLUMN receiving_doctor_id INT NULL AFTER requested_by_hospital_id,
    ADD CONSTRAINT fk_incidents_req_user     FOREIGN KEY (requested_by_user_id)     REFERENCES users(id)     ON DELETE SET NULL,
    ADD CONSTRAINT fk_incidents_req_hospital FOREIGN KEY (requested_by_hospital_id) REFERENCES hospitals(id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_incidents_doctor       FOREIGN KEY (receiving_doctor_id)      REFERENCES doctors(id)   ON DELETE SET NULL,
    ADD INDEX idx_incidents_req_hosp_time (requested_by_hospital_id, dispatched_at);

-- Who changed what, and when
CREATE TABLE IF NOT EXISTS activity_log (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    hospital_id  INT NOT NULL,
    user_id      INT NULL,                  -- NULL = done by the system (e.g. shift schedule)
    action       VARCHAR(50) NOT NULL,      -- e.g. resource.updated, doctor.status_changed
    entity_type  VARCHAR(30) NOT NULL,      -- resource, doctor, staff, shift, account
    entity_id    INT NULL,
    summary      VARCHAR(255) NOT NULL,     -- human-readable line shown in the UI
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_activity_hospital FOREIGN KEY (hospital_id) REFERENCES hospitals(id) ON DELETE CASCADE,
    CONSTRAINT fk_activity_user     FOREIGN KEY (user_id)     REFERENCES users(id)     ON DELETE SET NULL,
    INDEX idx_activity_hosp_time (hospital_id, created_at)
);
