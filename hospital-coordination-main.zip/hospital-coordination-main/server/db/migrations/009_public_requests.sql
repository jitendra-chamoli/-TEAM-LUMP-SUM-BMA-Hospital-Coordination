-- Public ambulance requests: a member of the public (often a bystander) books an
-- ambulance without any hospital account. Adds the citizen side, unidentified-patient
-- handling, and the payer/cost information hospitals publish.

-- People who book from the public app. Deliberately NOT in `users`: a citizen must
-- never be able to read hospital data, and a separate table makes that structural.
CREATE TABLE IF NOT EXISTS public_users (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    phone        VARCHAR(20) NOT NULL UNIQUE,
    name         VARCHAR(100) NULL,
    blood_group  VARCHAR(5) NULL,
    allergies    VARCHAR(255) NULL,
    conditions   VARCHAR(255) NULL,
    is_blocked   BOOLEAN NOT NULL DEFAULT FALSE,   -- abuse control
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_seen_at DATETIME NULL
);

-- One-time codes for phone sign-in. Only the hash is stored.
CREATE TABLE IF NOT EXISTS otp_codes (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    phone       VARCHAR(20) NOT NULL,
    code_hash   VARCHAR(255) NOT NULL,
    expires_at  DATETIME NOT NULL,
    attempts    TINYINT UNSIGNED NOT NULL DEFAULT 0,
    consumed_at DATETIME NULL,
    created_at  DATETIME NOT NULL,
    INDEX idx_otp_phone (phone, created_at)
);

ALTER TABLE incidents
    ADD COLUMN source ENUM('hospital', 'public') NOT NULL DEFAULT 'hospital' AFTER status,
    ADD COLUMN public_user_id INT NULL AFTER requested_by_hospital_id,
    -- Who is booking. 'bystander' switches on the Good Samaritan / unidentified path.
    ADD COLUMN requester_relationship ENUM('self', 'family', 'bystander') NULL AFTER public_user_id,
    ADD COLUMN patient_identified BOOLEAN NOT NULL DEFAULT TRUE AFTER requester_relationship,
    -- Medico-legal case: hospital must inform police (trauma, burns, assault, poisoning)
    ADD COLUMN is_mlc BOOLEAN NOT NULL DEFAULT FALSE AFTER patient_identified,
    ADD COLUMN motor_vehicle_involved BOOLEAN NULL AFTER is_mlc,
    ADD COLUMN vehicle_numbers VARCHAR(120) NULL AFTER motor_vehicle_involved,
    -- Which payment route the hospital should pursue; decided from cause + payer answer
    ADD COLUMN payer_route ENUM('mv_cashless', 'pmjay', 'state_scheme', 'insurance', 'self_pay', 'unknown') NULL AFTER vehicle_numbers,
    ADD COLUMN payer_note VARCHAR(120) NULL AFTER payer_route,
    ADD COLUMN police_informed_at DATETIME NULL AFTER payer_note,
    ADD CONSTRAINT fk_incidents_public_user FOREIGN KEY (public_user_id) REFERENCES public_users(id) ON DELETE SET NULL,
    ADD INDEX idx_incidents_source (source, status);

ALTER TABLE hospitals
    ADD COLUMN type ENUM('government', 'trust', 'private') NOT NULL DEFAULT 'private' AFTER phone,
    ADD COLUMN is_trauma_centre BOOLEAN NOT NULL DEFAULT FALSE AFTER type;

-- Which payment schemes / insurers each hospital is empanelled for.
CREATE TABLE IF NOT EXISTS hospital_schemes (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    hospital_id INT NOT NULL,
    scheme      VARCHAR(40) NOT NULL,
    CONSTRAINT uq_hospital_scheme UNIQUE (hospital_id, scheme),
    CONSTRAINT fk_schemes_hospital FOREIGN KEY (hospital_id) REFERENCES hospitals(id) ON DELETE CASCADE
);

-- Published arrival costs, maintained by each hospital's admin. Only the few items
-- that are predictable before a patient is examined.
CREATE TABLE IF NOT EXISTS hospital_tariffs (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    hospital_id INT NOT NULL,
    item        VARCHAR(40) NOT NULL,
    min_price   INT NOT NULL,
    max_price   INT NULL,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_tariff_range CHECK (max_price IS NULL OR max_price >= min_price),
    CONSTRAINT uq_hospital_tariff UNIQUE (hospital_id, item),
    CONSTRAINT fk_tariffs_hospital FOREIGN KEY (hospital_id) REFERENCES hospitals(id) ON DELETE CASCADE
);
