// The handful of widgets this app needs. Deliberately smaller and chunkier than
// the hospital portal's kit: everything here is sized for a thumb.

import React from 'react';
import { twMerge } from 'tailwind-merge';
import { Dialog as RDialog, Switch as RSwitch, RadioGroup as RRadio } from 'radix-ui';
import { ChevronDown, X } from 'lucide-react';

export const cn = (...classes) => twMerge(classes.filter(Boolean).join(' '));

const ring = 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500/40 focus-visible:ring-offset-1';

// ---------------- Button ---------------- //

const VARIANTS = {
    primary: 'bg-brand-600 text-white hover:bg-brand-700 shadow-sm',
    danger: 'bg-red-600 text-white hover:bg-red-700 shadow-sm',
    secondary: 'bg-white text-slate-700 border border-line hover:bg-slate-50',
    ghost: 'text-slate-600 hover:bg-slate-100'
};
const SIZES = { md: 'h-10 px-4 text-sm gap-2', lg: 'h-12 px-5 text-base gap-2', icon: 'h-9 w-9 justify-center' };

export const Button = ({ variant = 'primary', size = 'md', className, type = 'button', children, ...props }) => (
    <button type={type}
        className={cn('inline-flex items-center justify-center rounded-xl font-semibold transition-colors select-none',
            'disabled:opacity-50 disabled:pointer-events-none [&_svg]:shrink-0 active:scale-[0.99]',
            ring, VARIANTS[variant], SIZES[size], className)}
        {...props}>
        {children}
    </button>
);

// ---------------- Fields ---------------- //

// h-11 and 16px text: anything smaller makes iOS zoom in on focus.
const field = 'w-full h-11 rounded-xl border border-line bg-white text-base text-slate-900 placeholder:text-slate-400 ' +
    'transition-colors focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 disabled:bg-slate-50';

export const Input = React.forwardRef(({ icon: Icon, right, className, ...props }, ref) => (
    <div className="relative">
        {Icon && <Icon size={17} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />}
        <input ref={ref} className={cn(field, Icon ? 'pl-11' : 'pl-3.5', right ? 'pr-11' : 'pr-3.5', className)} {...props} />
        {right && <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center">{right}</div>}
    </div>
));
Input.displayName = 'Input';

export const Select = ({ className, children, ...props }) => (
    <div className="relative">
        <select className={cn(field, 'appearance-none pl-3.5 pr-10 cursor-pointer', className)} {...props}>{children}</select>
        <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
    </div>
);

export const Field = ({ label, htmlFor, hint, className, children }) => (
    <div className={className}>
        {label && <label htmlFor={htmlFor} className="block text-sm font-medium text-slate-700 mb-1.5">{label}</label>}
        {children}
        {hint && <p className="text-xs text-slate-500 mt-1.5">{hint}</p>}
    </div>
);

export const Switch = ({ checked, onCheckedChange, id, label, className }) => (
    <span className={cn('inline-flex items-center gap-3', className)}>
        <RSwitch.Root id={id} checked={checked} onCheckedChange={onCheckedChange}
            className={cn('relative h-6 w-11 shrink-0 rounded-full bg-slate-300 transition-colors data-[state=checked]:bg-brand-600 cursor-pointer', ring)}>
            <RSwitch.Thumb className="block h-5 w-5 rounded-full bg-white shadow-sm transition-transform translate-x-0.5 data-[state=checked]:translate-x-[22px]" />
        </RSwitch.Root>
        {label && <label htmlFor={id} className="text-sm text-slate-700 cursor-pointer select-none">{label}</label>}
    </span>
);

// ---------------- Choice tiles ---------------- //

/** Big tappable options. `columns` 1 for stacked rows, 2 for a grid of tiles. */
export const Choice = ({ value, onChange, options, columns = 1, label, className }) => (
    <RRadio.Root value={value || ''} onValueChange={onChange} aria-label={label}
        className={cn('grid gap-2', columns === 2 ? 'grid-cols-2' : 'grid-cols-1', className)}>
        {options.map(o => (
            <RRadio.Item key={o.value} value={o.value}
                className={cn('text-left rounded-xl border-2 border-line bg-white transition-colors',
                    columns === 2 ? 'p-3 flex flex-col items-start gap-2' : 'px-4 py-3',
                    'data-[state=checked]:border-brand-600 data-[state=checked]:bg-brand-50/60', ring)}>
                {o.icon && <o.icon size={20} className="text-slate-500" />}
                <span className="flex items-center gap-2">
                    {o.dot && <span className={cn('h-2.5 w-2.5 rounded-full shrink-0', o.dot)} />}
                    <span className="font-semibold text-slate-900 leading-tight">{o.label}</span>
                </span>
                {o.hint && <span className="block text-xs text-slate-500 mt-0.5">{o.hint}</span>}
            </RRadio.Item>
        ))}
    </RRadio.Root>
);

// ---------------- Badge ---------------- //

const TONES = {
    neutral: 'bg-slate-100 text-slate-600 border-slate-200',
    green: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    amber: 'bg-amber-50 text-amber-700 border-amber-200',
    red: 'bg-red-50 text-red-700 border-red-200',
    blue: 'bg-brand-50 text-brand-700 border-brand-100',
    sky: 'bg-sky-50 text-sky-700 border-sky-200',
    violet: 'bg-violet-50 text-violet-700 border-violet-200'
};
const DOTS = { neutral: 'bg-slate-400', green: 'bg-emerald-500', amber: 'bg-amber-500', red: 'bg-red-500', blue: 'bg-brand-500', sky: 'bg-sky-500', violet: 'bg-violet-500' };

export const Badge = ({ tone = 'neutral', dot, icon: Icon, className, children }) => (
    <span className={cn('inline-flex items-center gap-1.5 h-7 px-2.5 rounded-lg border text-xs font-semibold whitespace-nowrap', TONES[tone], className)}>
        {dot && <span className={cn('h-1.5 w-1.5 rounded-full', DOTS[tone])} />}
        {Icon && <Icon size={13} />}
        {children}
    </span>
);

// ---------------- Notice ---------------- //

const NOTICE = {
    info: 'bg-brand-50 border-brand-100 text-brand-900',
    good: 'bg-emerald-50 border-emerald-200 text-emerald-900',
    warn: 'bg-amber-50 border-amber-200 text-amber-900',
    bad: 'bg-red-50 border-red-200 text-red-800'
};

export const Notice = ({ tone = 'info', icon: Icon, title, children, className }) => (
    <div className={cn('rounded-xl border p-4 flex gap-3 text-sm', NOTICE[tone], className)} role={tone === 'bad' ? 'alert' : undefined}>
        {Icon && <Icon size={18} className="shrink-0 mt-0.5" />}
        <div className="min-w-0">
            {title && <p className="font-semibold">{title}</p>}
            {children && <div className={title ? 'mt-1' : ''}>{children}</div>}
        </div>
    </div>
);

// ---------------- Dialog ---------------- //

export const Dialog = ({ open, onOpenChange, title, description, children, footer }) => (
    <RDialog.Root open={open} onOpenChange={onOpenChange}>
        <RDialog.Portal>
            <RDialog.Overlay className="fixed inset-0 z-50 bg-slate-900/40 data-[state=open]:animate-in data-[state=open]:fade-in-0" />
            <RDialog.Content className="fixed left-1/2 top-1/2 z-50 w-[calc(100%-2rem)] max-w-sm -translate-x-1/2 -translate-y-1/2 rounded-2xl bg-white shadow-xl data-[state=open]:animate-in data-[state=open]:zoom-in-95">
                <div className="p-5 pb-0">
                    <RDialog.Title className="text-base font-semibold text-slate-900 pr-8">{title}</RDialog.Title>
                    {description
                        ? <RDialog.Description className="text-sm text-slate-600 mt-1">{description}</RDialog.Description>
                        : <RDialog.Description className="sr-only">{title}</RDialog.Description>}
                </div>
                <RDialog.Close asChild>
                    <button className={cn('absolute right-3 top-3 h-9 w-9 rounded-lg grid place-items-center text-slate-400 hover:bg-slate-100', ring)} aria-label="Close">
                        <X size={17} />
                    </button>
                </RDialog.Close>
                {children && <div className="p-5">{children}</div>}
                {footer && <div className="flex gap-2 px-5 py-4 border-t border-line">{footer}</div>}
            </RDialog.Content>
        </RDialog.Portal>
    </RDialog.Root>
);

// ---------------- Misc ---------------- //

export const Skeleton = ({ className }) => <div className={cn('animate-pulse rounded-xl bg-slate-200/70', className)} />;

/** Fixed bar at the bottom of the screen, clear of the phone's home indicator. */
export const BottomBar = ({ children }) => (
    <div className="fixed bottom-0 inset-x-0 bg-white border-t border-line px-4 py-3 z-30"
        style={{ paddingBottom: 'calc(0.75rem + env(safe-area-inset-bottom, 0px))' }}>
        <div className="max-w-md mx-auto flex gap-2">{children}</div>
    </div>
);

export const Screen = ({ children, className }) => (
    <div className={cn('min-h-full bg-canvas', className)}>{children}</div>
);

export const Header = ({ title, left, right }) => (
    <header className="sticky z-30 bg-white border-b border-line px-4 h-14 flex items-center gap-3"
        style={{ top: 'env(safe-area-inset-top, 0px)' }}>
        {left}
        <p className="font-semibold text-slate-900 truncate">{title}</p>
        {right && <div className="ml-auto flex items-center gap-2">{right}</div>}
    </header>
);
