import React, { useState, useEffect, useCallback } from 'react';
import { Phone, History as HistoryIcon, AlertTriangle } from 'lucide-react';
import { api, startSession, getToken, errorText, SESSION_LOST } from './api';
import { isActive, FALLBACK_EMERGENCY_NUMBER, telHref } from './constants';
import { Skeleton, Screen, Notice } from './ui';
import Booking from './screens/Booking';
import Tracking from './screens/Tracking';
import History from './screens/History';

/**
 * The citizen ambulance app.
 *
 * There is no sign-in screen and no SOS screen: the app opens on the booking form
 * with the location already resolving, because every tap between opening the app
 * and dispatching is a second the patient waits.
 */
const App = () => {
  const [config, setConfig] = useState(null);
  const [profile, setProfile] = useState(null);
  const [request, setRequest] = useState(null);
  const [screen, setScreen] = useState('booking');
  const [ready, setReady] = useState(false);
  const [error, setError] = useState('');
  const [reloads, setReloads] = useState(0);

  const emergencyNumber = config?.emergency_number || FALLBACK_EMERGENCY_NUMBER;
  const reload = useCallback(() => setReloads(n => n + 1), []);

  // Config and the device session are fetched together, before the form paints, so
  // the caller never waits on a sign-in step.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [configRes, user] = await Promise.all([
          api.get('/api/public/config'),
          getToken() ? Promise.resolve(null) : startSession()
        ]);
        if (cancelled) return;
        setConfig(configRes.data);
        if (user) setProfile(user);
      } catch (err) {
        if (!cancelled) setError(errorText(err, `Could not reach the service. Please call ${FALLBACK_EMERGENCY_NUMBER}.`));
        return;
      }

      try {
        const me = await api.get('/api/public/me');
        if (cancelled) return;
        setProfile(me.data.user);
        setRequest(me.data.active_request);
      } catch {
        /* a brand-new device has nothing to restore */
      } finally {
        if (!cancelled) setReady(true);
      }
    })();
    return () => { cancelled = true; };
  }, [reloads]);

  // A lost session is recoverable without bothering the caller: quietly make a new one.
  useEffect(() => {
    const onLost = () => { startSession().then(reload).catch(() => {}); };
    window.addEventListener(SESSION_LOST, onLost);
    return () => window.removeEventListener(SESSION_LOST, onLost);
  }, [reload]);

  if (error) {
    return (
      <Screen className="p-5 flex flex-col justify-center">
        <div className="max-w-md mx-auto w-full flex flex-col items-center gap-4 text-center">
          <Notice tone="bad" icon={AlertTriangle}>{error}</Notice>
          <a href={telHref(FALLBACK_EMERGENCY_NUMBER)}
            className="inline-flex items-center justify-center gap-2 h-12 px-6 rounded-xl bg-red-600 text-white font-semibold">
            <Phone size={18} /> Call {FALLBACK_EMERGENCY_NUMBER}
          </a>
        </div>
      </Screen>
    );
  }

  if (!config || !ready) {
    return (
      <Screen className="p-5">
        <div className="max-w-md mx-auto w-full flex flex-col gap-4 pt-6">
          <Skeleton className="h-8 w-1/2" />
          <Skeleton className="h-52" />
          <Skeleton className="h-28" />
        </div>
      </Screen>
    );
  }

  // An ambulance on its way takes over the app: it's the only thing that matters.
  if (request && isActive(request.status)) {
    return <Tracking request={request} emergencyNumber={emergencyNumber}
      onFinished={() => { setRequest(null); setScreen('booking'); }} />;
  }

  if (screen === 'history') return <History onBack={() => setScreen('booking')} />;

  return (
    <Booking
      config={config}
      profile={profile}
      emergencyNumber={emergencyNumber}
      onBooked={setRequest}
      onOpenHistory={() => setScreen('history')}
    />
  );
};

export default App;
