import { HeartPulse, Brain, Bone, Wind, Zap, Baby, Flame, FlaskConical, HelpCircle, Users } from 'lucide-react';

// Matches the complaint codes the server sends from /api/public/config.
export const COMPLAINT_ICONS = {
    chest_pain: HeartPulse, stroke: Brain, trauma: Bone, breathing: Wind, unconscious: Zap,
    pregnancy: Users, child: Baby, burns: Flame, poisoning: FlaskConical, other: HelpCircle
};

export const WHO = [
    { value: 'self', label: 'Me', hint: "I'm the patient" },
    { value: 'family', label: 'Family or friend', hint: 'Someone I know' },
    { value: 'bystander', label: 'A stranger', hint: 'I saw it happen' }
];

export const SEVERITY = [
    { value: 'critical', label: 'Life-threatening', hint: 'Not breathing, heavy bleeding, unconscious', dot: 'bg-red-500', tone: 'red' },
    { value: 'serious', label: 'Serious', hint: 'Needs a hospital quickly', dot: 'bg-amber-500', tone: 'amber' },
    { value: 'stable', label: 'Stable', hint: 'Awake and talking', dot: 'bg-emerald-500', tone: 'green' }
];
export const severityMeta = (v) => SEVERITY.find(s => s.value === v);

// Status wording written for a worried member of the public, not a dispatcher.
export const STATUS = {
    requested: { label: 'Finding a hospital', tone: 'amber', detail: 'An ambulance is already on its way to you.' },
    accepted: { label: 'Hospital confirmed', tone: 'blue', detail: 'The ambulance is on its way.' },
    picked_up: { label: 'On the way to hospital', tone: 'violet', detail: 'The patient is in the ambulance.' },
    arrived: { label: 'Arrived at hospital', tone: 'sky', detail: 'The hospital team is taking over.' },
    handed_over: { label: 'Handed over', tone: 'green', detail: 'The patient is with the hospital team.' },
    closed: { label: 'Closed', tone: 'neutral', detail: '' },
    cancelled: { label: 'Cancelled', tone: 'neutral', detail: '' },
    unplaced: { label: 'Still finding a hospital', tone: 'red', detail: 'The ambulance is with you. We are still arranging a hospital.' }
};

export const isActive = (status) => ['requested', 'accepted', 'picked_up', 'arrived', 'unplaced'].includes(status);

export const CANCEL_REASONS = [
    'False alarm',
    'Patient no longer needs an ambulance',
    'Going by other transport',
    'Booked by mistake',
    'Other'
];

// 108 is India's free government ambulance line (run by GVK EMRI in most states).
// 112 is the all-India emergency number and 102 is maternal transport in some states,
// so the deployment picks via EMERGENCY_NUMBER on the server.
export const FALLBACK_EMERGENCY_NUMBER = '108';

export const telHref = (number) => `tel:${String(number).replace(/\s/g, '')}`;
