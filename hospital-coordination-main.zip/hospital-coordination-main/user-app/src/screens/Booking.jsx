import React, { useState, useEffect, lazy, Suspense } from 'react';
import { Siren, ChevronRight, ShieldCheck, Phone, Loader2, AlertTriangle, History as HistoryIcon } from 'lucide-react';
import { api, errorText } from '../api';
import { COMPLAINT_ICONS, WHO, SEVERITY, telHref } from '../constants';
import { Button, Input, Field, Select, Switch, Choice, Notice, Skeleton, Screen, BottomBar } from '../ui';

const LocationPicker = lazy(() => import('../components/LocationPicker'));

const Block = ({ title, children, hint }) => (
  <section className="flex flex-col gap-2.5">
    <div>
      <h2 className="text-sm font-semibold text-slate-900">{title}</h2>
      {hint && <p className="text-xs text-slate-500 mt-0.5">{hint}</p>}
    </div>
    {children}
  </section>
);

/**
 * One screen. The only thing that must be known before an ambulance can move is
 * where to send it; everything else is optional and can be added while it drives.
 */
const Booking = ({ config, profile, emergencyNumber, onBooked, onOpenHistory }) => {
  const [location, setLocation] = useState(null);
  const [locating, setLocating] = useState(true);
  const [phone, setPhone] = useState(profile?.phone?.replace('+91', '') || '');
  const [who, setWho] = useState(null);
  const [complaint, setComplaint] = useState(null);
  const [severity, setSeverity] = useState(null);
  const [needsIcu, setNeedsIcu] = useState(false);
  const [patientUnknown, setPatientUnknown] = useState(false);
  const [motorVehicle, setMotorVehicle] = useState(false);
  const [details, setDetails] = useState({ name: '', age: '', notes: '', vehicle_numbers: '' });
  const [payer, setPayer] = useState('unknown');
  const [payerNote, setPayerNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  // Location starts resolving the instant the screen appears — it's the only thing
  // the dispatch genuinely needs, so it must never be waiting on a tap.
  useEffect(() => {
    if (!navigator.geolocation) { queueMicrotask(() => setLocating(false)); return; }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude: lat, longitude: lng } = pos.coords;
        setLocation({ lat, lng, address: '', city: '' });
        setLocating(false);
        try {
          const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
          const data = await res.json();
          setLocation(l => (l ? { ...l, address: data?.display_name || '', city: data?.address?.city || data?.address?.town || data?.address?.county || '' } : l));
        } catch { /* an address is nice to have; the coordinates are what matter */ }
      },
      () => setLocating(false),
      { enableHighAccuracy: true, timeout: 15000 }
    );
  }, []);

  const bystander = who === 'bystander';
  const unknownPatient = bystander && patientUnknown;
  // A bystander can't commit a stranger to a private bill, so the payer question is
  // only asked of the patient or their family.
  const askPayer = who === 'self' || who === 'family';
  const isTrauma = complaint === 'trauma';

  const book = async () => {
    setBusy(true); setError('');
    try {
      const res = await api.post('/api/public/requests', {
        patient_lat: location.lat,
        patient_lng: location.lng,
        pickup_address: location.address || undefined,
        city: location.city || undefined,
        caller_phone: phone || undefined,
        complaint: complaint || undefined,
        severity: severity || undefined,
        needs_icu: needsIcu,
        relationship: who || undefined,
        patient_identified: who ? !unknownPatient : undefined,
        patient_name: (who === 'self' ? profile?.name : details.name) || undefined,
        patient_age: details.age === '' ? undefined : Number(details.age),
        notes: details.notes || undefined,
        motor_vehicle_involved: isTrauma ? motorVehicle : undefined,
        vehicle_numbers: isTrauma && details.vehicle_numbers ? details.vehicle_numbers : undefined,
        payer: askPayer ? payer : undefined,
        payer_note: askPayer && payer === 'insurance' ? payerNote || undefined : undefined
      });
      onBooked(res.data);
    } catch (err) {
      if (err.response?.data?.active_request) return onBooked(err.response.data.active_request);
      setError(errorText(err, `Could not book an ambulance. Please call ${emergencyNumber}.`));
      setBusy(false);
    }
  };

  return (
    <Screen className="pb-32">
      <header className="bg-white border-b border-line px-4 h-14 flex items-center gap-3">
        <div className="h-8 w-8 rounded-lg bg-red-600 text-white grid place-items-center"><Siren size={16} /></div>
        <p className="font-semibold text-slate-900">Emergency ambulance</p>
        <button onClick={onOpenHistory} className="ml-auto text-slate-400 hover:text-slate-700" aria-label="Past requests">
          <HistoryIcon size={18} />
        </button>
      </header>

      <div className="max-w-md mx-auto px-4 py-5 flex flex-col gap-6">
        {/* The map comes first: where the ambulance goes is the one thing that must be right. */}
        <Block title="Where to send the ambulance"
          hint={locating ? undefined : location ? 'Drag the pin or tap the map if it isn’t exactly right.' : undefined}>
          {locating && (
            <p className="text-sm text-slate-500 flex items-center gap-2"><Loader2 size={15} className="animate-spin" /> Finding your location…</p>
          )}
          {!locating && !location && (
            <p className="text-sm text-amber-800 flex items-start gap-2">
              <AlertTriangle size={15} className="mt-0.5 shrink-0" />
              We couldn't get your location. Search for the place, or tap it on the map.
            </p>
          )}
          <Suspense fallback={<Skeleton className="h-[40vh]" />}>
            <LocationPicker value={location} onChange={setLocation} mapClassName="h-[40vh] min-h-56"
              placeholder="Search a landmark or address…" />
          </Suspense>
        </Block>

        <Block title="Your number" hint="So the ambulance crew can call you. We won't send you a code.">
          <Input id="caller-phone" type="tel" inputMode="numeric" autoComplete="tel" icon={Phone}
            placeholder="98765 43210" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </Block>

        <Block title="What happened?" hint="Helps us pick a hospital with the right specialist. Leave it if you're not sure.">
          <Choice columns={2} value={complaint} onChange={setComplaint} label="What happened"
            options={config.complaints.map(c => ({ value: c.code, label: c.label, icon: COMPLAINT_ICONS[c.code] }))} />
          {isTrauma && (
            <Switch id="motor-vehicle" checked={motorVehicle} onCheckedChange={setMotorVehicle}
              label="A vehicle was involved (road accident)" />
          )}
          {isTrauma && motorVehicle && (
            <Notice tone="good">
              Road accident victims get cashless treatment under the government scheme. The hospital handles the paperwork.
            </Notice>
          )}
        </Block>

        <Block title="How bad is it?">
          <Choice value={severity} onChange={setSeverity} options={SEVERITY} label="How bad is it" />
          {severity === 'critical' && (
            <p className="text-xs text-slate-600 bg-slate-100 rounded-lg px-3 py-2.5">
              We'll send the patient to the nearest hospital that can treat this, whatever it costs.
              By law they must stabilise the patient regardless of payment.
            </p>
          )}
          <Switch id="needs-icu" checked={needsIcu} onCheckedChange={setNeedsIcu} label="Likely to need intensive care" />
        </Block>

        <Block title="Who needs the ambulance?">
          <Choice value={who} onChange={setWho} options={WHO} label="Who needs the ambulance" />
          {bystander && (
            <>
              <Notice tone="good" icon={ShieldCheck} title="You won't be charged.">
                Indian law protects people who help accident victims. The hospital cannot ask you to pay,
                you don't have to give your name, and you can leave once the ambulance arrives.
              </Notice>
              <Switch id="patient-unknown" checked={patientUnknown} onCheckedChange={setPatientUnknown}
                label="I don't know who this person is" />
            </>
          )}
        </Block>

        <details className="rounded-xl border border-line bg-white group">
          <summary className="px-4 py-3.5 cursor-pointer text-sm font-medium text-slate-700 flex items-center gap-1.5 select-none">
            <ChevronRight size={15} className="transition-transform group-open:rotate-90" />
            More details for the hospital
          </summary>
          <div className="px-4 pb-4 flex flex-col gap-4">
            {!unknownPatient && (
              <div className="grid grid-cols-3 gap-3">
                <Field label="Patient name" htmlFor="d-name" className="col-span-2">
                  <Input id="d-name" value={details.name} onChange={(e) => setDetails({ ...details, name: e.target.value })}
                    placeholder={who === 'self' ? profile?.name || 'Your name' : 'If known'} />
                </Field>
                <Field label="Age" htmlFor="d-age">
                  <Input id="d-age" inputMode="numeric" value={details.age}
                    onChange={(e) => setDetails({ ...details, age: e.target.value.replace(/\D/g, '').slice(0, 3) })} />
                </Field>
              </div>
            )}
            <Field label="Anything the hospital should know" htmlFor="d-notes">
              <Input id="d-notes" maxLength={500} value={details.notes}
                onChange={(e) => setDetails({ ...details, notes: e.target.value })}
                placeholder="e.g. conscious, bleeding from the left leg" />
            </Field>
            {isTrauma && motorVehicle && (
              <Field label="Vehicle numbers, if you can see them" htmlFor="d-vehicles" hint="Helps the hospital claim under the accident scheme.">
                <Input id="d-vehicles" value={details.vehicle_numbers}
                  onChange={(e) => setDetails({ ...details, vehicle_numbers: e.target.value })} placeholder="UK07 AB 1234" />
              </Field>
            )}
            {askPayer && (
              <Field label="How will treatment be paid for?" htmlFor="d-payer"
                hint={severity === 'critical'
                  ? 'Not used for life-threatening cases — the patient goes to the nearest capable hospital.'
                  : 'We prefer hospitals where this works.'}>
                <Select id="d-payer" value={payer} onChange={(e) => setPayer(e.target.value)}>
                  {config.payer_options.map(o => <option key={o.code} value={o.code}>{o.label}</option>)}
                </Select>
              </Field>
            )}
            {askPayer && payer === 'insurance' && (
              <Field label="Insurer or TPA" htmlFor="d-insurer">
                <Input id="d-insurer" value={payerNote} onChange={(e) => setPayerNote(e.target.value)} placeholder="e.g. Star Health" />
              </Field>
            )}
          </div>
        </details>

        {error && <Notice tone="bad" icon={AlertTriangle}>{error}</Notice>}

        <p className="text-xs text-slate-500 text-center">
          Not getting a response? Call the {config.emergency_label || 'government ambulance helpline'}{' '}
          <a href={telHref(emergencyNumber)} className="font-semibold text-red-700 underline">{emergencyNumber}</a>.
        </p>
      </div>

      <BottomBar>
        <div className="flex-1">
          <Button variant="danger" size="lg" className="w-full h-14" disabled={!location || busy} onClick={book}>
            <Siren size={18} /> {busy ? 'Sending…' : 'Send ambulance'}
          </Button>
          <p className="text-xs text-slate-500 text-center mt-2">
            {location
              ? 'You can add the rest while it’s on its way.'
              : 'Waiting for your location — everything else is optional.'}
          </p>
        </div>
      </BottomBar>
    </Screen>
  );
};

export default Booking;
