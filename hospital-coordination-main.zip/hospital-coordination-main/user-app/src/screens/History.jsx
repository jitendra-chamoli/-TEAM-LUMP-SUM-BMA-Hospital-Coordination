import React, { useState, useEffect } from 'react';
import { api } from '../api';
import { STATUS } from '../constants';
import { Badge, Skeleton, Screen, Header } from '../ui';

const History = ({ onBack }) => {
  const [rows, setRows] = useState(null);

  useEffect(() => {
    let cancelled = false;
    api.get('/api/public/requests')
      .then(res => { if (!cancelled) setRows(res.data); })
      .catch(() => { if (!cancelled) setRows([]); });
    return () => { cancelled = true; };
  }, []);

  return (
    <Screen>
      <Header title="Your requests" left={<button onClick={onBack} className="text-sm text-slate-500">Back</button>} />
      <div className="max-w-md mx-auto px-4 py-5 flex flex-col gap-2">
        {rows === null ? (
          <><Skeleton className="h-16" /><Skeleton className="h-16" /></>
        ) : rows.length === 0 ? (
          <p className="text-sm text-slate-500 text-center py-12">You haven't booked an ambulance yet.</p>
        ) : rows.map(r => {
          const s = STATUS[r.status] || { label: r.status, tone: 'neutral' };
          return (
            <div key={r.id} className="rounded-xl border border-line bg-white px-4 py-3">
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-medium text-slate-900">#{r.id} · {String(r.complaint || '').replace(/_/g, ' ')}</p>
                <Badge tone={s.tone}>{s.label}</Badge>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {new Date(r.dispatched_at).toLocaleString()}{r.hospital_name ? ` · ${r.hospital_name}` : ''}
              </p>
            </div>
          );
        })}
      </div>
    </Screen>
  );
};

export default History;
