import React, { useState, useEffect, useCallback, lazy, Suspense } from 'react';
import { Hospital, Stethoscope, Phone, ShieldCheck, X, CheckCircle2, Navigation, ChevronUp, ChevronDown } from 'lucide-react';
import { api, errorText } from '../api';
import { STATUS, isActive, CANCEL_REASONS, telHref } from '../constants';
import { Badge, Button, Dialog, Select, Notice, cn } from '../ui';

const TrackingMap = lazy(() => import('../components/TrackingMap'));

const POLL_MS = 5000;
// Height the collapsed sheet covers; the map keeps the route clear of it.
const PEEK_PX = 236;

// How much to trust the ETA, in plain words.
const ETA_BASIS = { mapbox: 'with live traffic', osrm: 'by road', estimate: 'rough estimate' };

const minutes = (seconds) => Math.max(1, Math.round(seconds / 60));

const Step = ({ done, current, label, time }) => (
  <li className="flex items-center gap-3">
    <span className={cn('h-5 w-5 shrink-0 rounded-full grid place-items-center border',
      done ? 'bg-emerald-500 border-emerald-500 text-white' : current ? 'border-brand-500 bg-brand-50' : 'border-line bg-white')}>
      {done ? <CheckCircle2 size={12} /> : current ? <span className="h-1.5 w-1.5 rounded-full bg-brand-500 animate-pulse" /> : null}
    </span>
    <span className={cn('text-sm flex-1', done || current ? 'text-slate-900' : 'text-slate-400')}>{label}</span>
    {time && <span className="text-xs text-slate-500 tabular">{new Date(time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>}
  </li>
);

/**
 * The one number people want -- how long until it gets here -- as large as possible,
 * and what it means in words underneath.
 */
const Headline = ({ request, active, emergencyNumber }) => {
  const status = STATUS[request.status] || STATUS.requested;
  // Before a driver accepts there is no ETA to give; say what is happening instead.
  if (active && !request.ambulance_name && request.ambulance_search === 'searching') {
    return (
      <div>
        <p className="text-2xl font-bold text-slate-900 flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-amber-500 animate-pulse" /> Finding the nearest ambulance
        </p>
        <p className="text-sm text-slate-600 mt-1">Drivers nearby are being asked to accept. This usually takes a few seconds.</p>
      </div>
    );
  }
  if (active && !request.ambulance_name && request.ambulance_search === 'failed') {
    return (
      <div>
        <p className="text-2xl font-bold text-red-700">No ambulance driver accepted</p>
        <p className="text-sm text-slate-700 mt-1">Please call {emergencyNumber} now.</p>
      </div>
    );
  }
  const eta = active ? request.eta : null;
  if (eta?.seconds != null) {
    const m = minutes(eta.seconds);
    const toYou = eta.leg === 'to_patient';
    return (
      <div>
        <p className="text-sm font-medium text-slate-600">{toYou ? 'Ambulance arriving in' : `Reaching ${request.hospital_name || 'hospital'} in`}</p>
        <p className="flex items-baseline gap-1.5 mt-0.5">
          <span className="text-5xl font-bold tracking-tight text-slate-900 tabular">{m < 60 ? m : `${Math.floor(m / 60)}h ${m % 60}`}</span>
          <span className="text-xl font-semibold text-slate-700">{m < 60 ? 'min' : ''}</span>
        </p>
        <p className="text-xs text-slate-500 mt-1">
          {eta.remaining_km.toFixed(1)} km{ETA_BASIS[eta.source] ? ` · ${ETA_BASIS[eta.source]}` : ''}
        </p>
      </div>
    );
  }
  return (
    <div>
      <p className="text-2xl font-bold text-slate-900">{status.label}</p>
      {status.detail && <p className="text-sm text-slate-600 mt-1">{status.detail}</p>}
    </div>
  );
};

/** What the person who booked sees while the ambulance is on its way. */
const Tracking = ({ request: initial, emergencyNumber, onFinished }) => {
  const [request, setRequest] = useState(initial);
  const [route, setRoute] = useState(null);
  const [expanded, setExpanded] = useState(false);
  const [recenter, setRecenter] = useState(0);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [reason, setReason] = useState(CANCEL_REASONS[0]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const refresh = useCallback(async () => {
    try {
      const res = await api.get(`/api/public/requests/${initial.id}`);
      setRequest(res.data);
    } catch { /* a dropped poll on a mobile network isn't worth showing */ }
  }, [initial.id]);

  // Polling rather than a socket: simpler, and far more forgiving of a patchy connection.
  useEffect(() => {
    if (!isActive(request.status)) return;
    const t = setInterval(refresh, POLL_MS);
    return () => clearInterval(t);
  }, [refresh, request.status]);

  // The poll carries only the route's version; the road itself is fetched when it
  // changes, or when the hospital does (that moves the patient-to-hospital leg).
  const routeVersion = request.eta?.route_version;
  const hospitalAt = request.hospital_lat;
  useEffect(() => {
    if (!routeVersion && !hospitalAt) return;
    let cancelled = false;
    api.get(`/api/public/requests/${request.id}/route`)
      .then(res => { if (!cancelled) setRoute(res.data); })
      .catch(() => { /* the map still works without it */ });
    return () => { cancelled = true; };
  }, [request.id, routeVersion, hospitalAt]);

  const cancel = async () => {
    setBusy(true); setError('');
    try {
      const res = await api.post(`/api/public/requests/${request.id}/cancel`, { reason });
      setRequest(res.data);
      setCancelOpen(false);
    } catch (err) {
      setError(errorText(err, 'Could not cancel.'));
    } finally {
      setBusy(false);
    }
  };

  const status = STATUS[request.status] || STATUS.requested;
  const active = isActive(request.status);
  const bystander = request.relationship === 'bystander';
  const ambulance = active && request.ambulance_lat ? [Number(request.ambulance_lat), Number(request.ambulance_lng)] : null;
  const showRoute = active && route?.geometry && route.leg === request.eta?.leg ? route.geometry : null;
  // The rest of the journey, patient to hospital, while the ambulance is still coming.
  const showAhead = active && !request.picked_up_at && route?.ahead?.geometry ? route.ahead.geometry : null;
  // The person most worth calling is the crew on their way; 108 if there isn't one.
  const callNumber = active && request.ambulance_contact ? request.ambulance_contact : emergencyNumber;
  const callLabel = active && request.ambulance_contact ? 'Call the ambulance' : `Call ${emergencyNumber}`;

  return (
    <div className="fixed inset-0 bg-canvas">
      {request.patient_lat && (
        <Suspense fallback={<div className="absolute inset-0 animate-pulse bg-slate-200" />}>
          <TrackingMap
            fill
            bottomPad={PEEK_PX}
            recenter={recenter}
            onRecenter={() => setRecenter(r => r + 1)}
            patient={[Number(request.patient_lat), Number(request.patient_lng)]}
            hospital={request.hospital_lat ? [Number(request.hospital_lat), Number(request.hospital_lng)] : null}
            ambulance={ambulance}
            hospitalName={request.hospital_name}
            ambulanceName={request.ambulance_name}
            route={showRoute}
            ahead={showAhead}
          />
        </Suspense>
      )}

      {/* Floating status, so the map can use the whole screen */}
      <div className="absolute top-0 inset-x-0 z-10 px-3 flex justify-between items-start pointer-events-none"
        style={{ paddingTop: 'calc(0.75rem + env(safe-area-inset-top, 0px))' }}>
        <span className="pointer-events-auto rounded-full bg-white/95 shadow-md px-3 py-1.5 text-xs font-medium text-slate-700">
          Request #{request.id}
        </span>
        <Badge tone={status.tone} dot className="pointer-events-auto shadow-md">{status.label}</Badge>
      </div>

      {/* Bottom sheet: the answer up top, everything else one tap away */}
      <section
        className="absolute bottom-0 inset-x-0 z-20 bg-white rounded-t-3xl shadow-[0_-8px_30px_rgba(15,23,42,0.18)] flex flex-col"
        style={{ maxHeight: expanded ? '78vh' : undefined, paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
        aria-label="Ambulance status"
      >
        <button onClick={() => setExpanded(e => !e)} className="w-full pt-2.5 pb-1 flex flex-col items-center gap-1 text-slate-400"
          aria-expanded={expanded} aria-label={expanded ? 'Show less' : 'Show details'}>
          <span className="h-1.5 w-10 rounded-full bg-slate-300" />
          {expanded ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
        </button>

        <div className={cn('max-w-md w-full mx-auto px-5 pb-4 flex flex-col gap-4', expanded && 'overflow-y-auto')}>
          <div className="flex items-start justify-between gap-3">
            <Headline request={request} active={active} emergencyNumber={emergencyNumber} />
            {active && request.ambulance_vehicle && (
              <div className="text-right shrink-0 rounded-xl bg-slate-50 border border-line px-3 py-2">
                <p className="text-[11px] text-slate-500">Ambulance</p>
                <p className="text-sm font-bold text-slate-900 tabular">{request.ambulance_vehicle}</p>
              </div>
            )}
          </div>

          {request.status === 'unplaced' && (
            <p className="text-sm text-slate-700 -mt-1">If nothing changes in the next few minutes, please call {emergencyNumber}.</p>
          )}
          {active && !request.ambulance_name && !request.ambulance_search && (
            <Notice tone="bad">No ambulance was free nearby. Please call {emergencyNumber} now.</Notice>
          )}

          {active ? (
            <div className="flex gap-2">
              <a href={telHref(callNumber)}
                className="flex-1 flex items-center justify-center gap-2 h-13 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold">
                <Phone size={18} /> {callLabel}
              </a>
              {expanded && (
                <Button variant="secondary" size="lg" className="h-13" onClick={() => setCancelOpen(true)}>
                  <X size={16} /> Cancel
                </Button>
              )}
            </div>
          ) : (
            <Button size="lg" className="w-full" onClick={onFinished}>Done</Button>
          )}

          {expanded && (
            <>
              {bystander && active && (
                <Notice tone="good" icon={ShieldCheck} title="You are not responsible for the bill.">
                  You can stay until the ambulance arrives and then leave. You don't have to give your name.
                </Notice>
              )}

              <div className="rounded-xl border border-line divide-y divide-line">
                <div className="flex gap-3 px-4 py-3.5">
                  <div className="h-9 w-9 rounded-lg grid place-items-center shrink-0 bg-brand-50 text-brand-600"><Hospital size={17} /></div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs text-slate-500">Hospital</p>
                    {request.hospital_name ? (
                      <>
                        <p className="text-sm font-semibold text-slate-900">{request.hospital_name}</p>
                        {request.hospital_address && <p className="text-xs text-slate-500 line-clamp-2">{request.hospital_address}</p>}
                        <div className="flex flex-wrap gap-3 mt-1.5">
                          {request.hospital_phone && <a href={telHref(request.hospital_phone)} className="text-sm text-brand-700 tabular">{request.hospital_phone}</a>}
                          {request.hospital_lat && (
                            <a href={`https://www.google.com/maps/dir/?api=1&destination=${request.hospital_lat},${request.hospital_lng}&travelmode=driving`}
                              target="_blank" rel="noreferrer" className="text-sm text-brand-700 inline-flex items-center gap-1">
                              <Navigation size={13} /> Directions
                            </a>
                          )}
                        </div>
                      </>
                    ) : <p className="text-sm text-slate-500">Being arranged. The ambulance is already on its way.</p>}
                  </div>
                </div>
                {request.receiving_doctor_name && (
                  <div className="flex gap-3 px-4 py-3.5">
                    <div className="h-9 w-9 rounded-lg grid place-items-center shrink-0 bg-violet-50 text-violet-600"><Stethoscope size={17} /></div>
                    <div>
                      <p className="text-xs text-slate-500">Doctor expecting the patient</p>
                      <p className="text-sm font-semibold text-slate-900">{request.receiving_doctor_name}</p>
                    </div>
                  </div>
                )}
              </div>

              <ol className="flex flex-col gap-3 px-1">
                <Step done label="Ambulance booked" time={request.created_at} />
                <Step done={!!request.accepted_at} current={!request.accepted_at && active} label="Hospital confirmed" time={request.accepted_at} />
                <Step done={!!request.picked_up_at} current={!!request.accepted_at && !request.picked_up_at} label="Patient picked up" time={request.picked_up_at} />
                <Step done={!!request.arrived_at} current={!!request.picked_up_at && !request.arrived_at} label="Arrived at hospital" time={request.arrived_at} />
                <Step done={!!request.handed_over_at} current={!!request.arrived_at && !request.handed_over_at} label="Handed to hospital team" time={request.handed_over_at} />
              </ol>
              {request.cancelled_at && (
                <p className="text-sm text-slate-600">Cancelled{request.cancel_reason ? ` · ${request.cancel_reason}` : ''}</p>
              )}

              {active && request.ambulance_contact && (
                <p className="text-xs text-slate-500 text-center">
                  Can't reach the crew? Call the government ambulance helpline{' '}
                  <a href={telHref(emergencyNumber)} className="font-semibold text-red-700 underline">{emergencyNumber}</a>.
                </p>
              )}
              {error && <Notice tone="bad">{error}</Notice>}
            </>
          )}
        </div>
      </section>

      <Dialog
        open={cancelOpen}
        onOpenChange={(v) => !busy && setCancelOpen(v)}
        title="Cancel this ambulance?"
        description="It will be sent to someone else. Only cancel if it's genuinely not needed."
        footer={
          <>
            <Button variant="secondary" className="flex-1" onClick={() => setCancelOpen(false)} disabled={busy}>Keep it</Button>
            <Button variant="danger" className="flex-1" onClick={cancel} disabled={busy}>{busy ? 'Cancelling…' : 'Yes, cancel'}</Button>
          </>
        }
      >
        <Select value={reason} onChange={(e) => setReason(e.target.value)} aria-label="Reason">
          {CANCEL_REASONS.map(r => <option key={r}>{r}</option>)}
        </Select>
      </Dialog>
    </div>
  );
};

export default Tracking;
