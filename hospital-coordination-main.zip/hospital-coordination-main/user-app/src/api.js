import axios from 'axios';

export const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

const TOKEN_KEY = 'bma.userToken';
const DEVICE_KEY = 'bma.deviceId';

// Identity is the device, not the phone number: typing a stranger's number must
// never reveal their booking history or their patient's live location. Generated
// once on first open and kept locally — the caller is never asked for anything.
export const getDeviceId = () => {
    try {
        let id = localStorage.getItem(DEVICE_KEY);
        if (!id) {
            id = crypto.randomUUID().replace(/-/g, '');
            localStorage.setItem(DEVICE_KEY, id);
        }
        return id;
    } catch {
        // Private browsing or blocked storage: a per-tab id still lets this visit work.
        if (!window.__bmaDeviceId) window.__bmaDeviceId = crypto.randomUUID().replace(/-/g, '');
        return window.__bmaDeviceId;
    }
};

export const getToken = () => {
    try { return localStorage.getItem(TOKEN_KEY); } catch { return window.__bmaToken || null; }
};
export const saveToken = (token) => {
    window.__bmaToken = token;
    try { localStorage.setItem(TOKEN_KEY, token); } catch { /* storage unavailable */ }
};
export const clearToken = () => {
    delete window.__bmaToken;
    try { localStorage.removeItem(TOKEN_KEY); } catch { /* storage unavailable */ }
};

export const api = axios.create({ baseURL: API_BASE_URL });

api.interceptors.request.use((config) => {
    const token = getToken();
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
});

export const SESSION_LOST = 'bma:session-lost';

api.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401 && getToken()) {
            clearToken();
            window.dispatchEvent(new CustomEvent(SESSION_LOST));
        }
        return Promise.reject(error);
    }
);

/** Creates (or resumes) this device's account. Asks the caller for nothing. */
export const startSession = async () => {
    const res = await api.post('/api/public/session', { device_id: getDeviceId() });
    saveToken(res.data.token);
    return res.data.user;
};

export const errorText = (err, fallback = 'Something went wrong. Please call 108.') => {
    const data = err?.response?.data;
    if (!data) return fallback;
    if (Array.isArray(data.details) && data.details.length > 0) return data.details.map(d => d.message).join(', ');
    return data.error || data.message || fallback;
};
