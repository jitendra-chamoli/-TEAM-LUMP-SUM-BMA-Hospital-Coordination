import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import { LocateFixed } from 'lucide-react';
import 'leaflet/dist/leaflet.css';

// Coloured pins so patient, hospital and ambulance are told apart at a glance.
const pin = (color, label) => L.divIcon({
    className: '',
    html: `<div style="display:flex;align-items:center;gap:4px;transform:translate(-8px,-8px)">
             <span style="flex-shrink:0;width:16px;height:16px;border-radius:9999px;background:${color};border:3px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.35)"></span>
             <span style="font:600 11px/1 'Public Sans',sans-serif;color:#0f172a;background:#fff;padding:2px 5px;border-radius:4px;box-shadow:0 1px 3px rgba(0,0,0,.2);white-space:nowrap">${label}</span>
           </div>`
});
// The ambulance is the thing people watch, so it is bigger and stands out.
const AMBULANCE = L.divIcon({
    className: '',
    html: `<div style="transform:translate(-17px,-17px);width:34px;height:34px;border-radius:9999px;background:#059669;border:3px solid #fff;
                box-shadow:0 2px 8px rgba(0,0,0,.35);display:grid;place-items:center;font-size:17px">🚑</div>`
});
const PINS = { patient: pin('#ef4444', 'You'), hospital: pin('#2563eb', 'Hospital') };

// Fits everything worth seeing, leaving room for whatever covers the bottom of the map.
// Refits when `fitKey` changes (a new route), not on every ambulance move, so a
// pinch-zoom isn't undone every few seconds.
const Fit = ({ points, bottomPad, fitKey, recenter }) => {
    const map = useMap();
    useEffect(() => {
        const t = setTimeout(() => {
            map.invalidateSize();
            if (points.length > 1) map.fitBounds(points, { paddingTopLeft: [32, 72], paddingBottomRight: [32, bottomPad + 24], maxZoom: 16 });
            else if (points.length === 1) map.setView(points[0], 15);
        }, 150);
        return () => clearTimeout(t);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [map, fitKey, recenter, bottomPad]);
    return null;
};

/**
 * patient / hospital / ambulance: [lat, lng] or null. route: [[lat, lng], ...] or null.
 * fill: cover the whole parent (the tracking screen) instead of a fixed-height card.
 */
// `ahead` is the road from the patient to the hospital, shown while the ambulance
// is still on its way to the patient so the whole journey is visible.
const TrackingMap = ({ patient, hospital, ambulance, hospitalName, ambulanceName, route, ahead, fill = false,
    bottomPad = 0, recenter = 0, onRecenter, className = 'h-56' }) => {
    const points = [...(route || []), ...(ahead || []), patient, hospital, ambulance].filter(Boolean);
    if (!patient) return null;
    const fitKey = `${route ? route.length : 0}:${ahead ? ahead.length : 0}:${hospital ? 1 : 0}:${ambulance ? 1 : 0}`;

    return (
        <div className={fill ? 'absolute inset-0 z-0' : `${className} rounded-xl overflow-hidden border border-line relative z-0`}>
            <MapContainer center={patient} zoom={14} zoomControl={!fill} attributionControl style={{ height: '100%', width: '100%' }}>
                <Fit points={points} bottomPad={bottomPad} fitKey={fitKey} recenter={recenter} />
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="&copy; OpenStreetMap" />
                {ahead && <Polyline positions={ahead} pathOptions={{ color: '#2563eb', weight: 4, dashArray: '8 8', opacity: 0.8 }} />}
                {hospital && !route && !ahead && <Polyline positions={[patient, hospital]} pathOptions={{ color: '#2563eb', weight: 2, dashArray: '6 6', opacity: 0.6 }} />}
                {route && <Polyline positions={route} pathOptions={{ color: '#ffffff', weight: 9, opacity: 0.9 }} />}
                {route && <Polyline positions={route} pathOptions={{ color: '#059669', weight: 5, opacity: 0.95 }} />}
                <Marker position={patient} icon={PINS.patient}><Popup>Pickup point</Popup></Marker>
                {hospital && <Marker position={hospital} icon={PINS.hospital}><Popup>{hospitalName}</Popup></Marker>}
                {ambulance && <Marker position={ambulance} icon={AMBULANCE} zIndexOffset={1000}><Popup>{ambulanceName}</Popup></Marker>}
            </MapContainer>
            {fill && onRecenter && (
                <button onClick={onRecenter} aria-label="Show the whole route"
                    className="absolute right-3 z-400 h-11 w-11 rounded-full bg-white shadow-md grid place-items-center text-slate-700"
                    style={{ bottom: bottomPad + 12 }}>
                    <LocateFixed size={19} />
                </button>
            )}
        </div>
    );
};

export default TrackingMap;
